<!DOCTYPE html>
<?php
    // Your existing PHP code...
    require_once 'logincheck.php';
    $date = date("Y", strtotime("+ 8 HOURS"));
    $conn = new mysqli("localhost", "root", "", "hcpms") or die(mysqli_error());
	 // Fetch data from the user table
	 $user_query = $conn->query("SELECT section, username FROM user") or die(mysqli_error());
	 $user_data = array();
 
	 while ($row = $user_query->fetch_assoc()) {
		 $user_data[] = $row;
	 }
    // Your existing queries go here...
    $qfecalysis = $conn->query("SELECT COUNT(*) as total FROM `fecalisys` WHERE `year` = '$date' GROUP BY `itr_no`") or die(mysqli_error());
	$ffecalysis = $qfecalysis->fetch_array();
	$qmaternity = $conn->query("SELECT COUNT(*) as total FROM `birthing` `prenatal` WHERE `year` = '$date' GROUP BY `itr_no`") or die(mysqli_error());
	$fmaternity = $qmaternity->fetch_array();
	$qhematology = $conn->query("SELECT COUNT(*) as total FROM `hematology` WHERE `year` = '$date' GROUP BY `itr_no`") or die(mysqli_error());
	$fhematology = $qhematology->fetch_array();
	$qdental = $conn->query("SELECT COUNT(*) as total FROM `dental` WHERE `year` = '$date' GROUP BY `itr_no`") or die(mysqli_error());
	$fdental = $qdental->fetch_array();
	$qxray = $conn->query("SELECT COUNT(*) as total FROM `radiological` WHERE `year` = '$date' GROUP BY `itr_no`") or die(mysqli_error());
	$fxray = $qxray->fetch_array();
	$qrehab = $conn->query("SELECT COUNT(*) as total FROM `rehabilitation` WHERE `year` = '$date' GROUP BY `itr_no`") or die(mysqli_error());
	$frehab = $qrehab->fetch_array();
	$qsputum = $conn->query("SELECT COUNT(*) as total FROM `sputum` WHERE `year` = '$date' GROUP BY `itr_no`") or die(mysqli_error());
	$fsputum = $qsputum->fetch_array();
	$qurinalysis = $conn->query("SELECT COUNT(*) as total FROM `urinalysis` WHERE `year` = '$date' GROUP BY `itr_no`") or die(mysqli_error());
	$furinalysis = $qurinalysis->fetch_array();
	$qfecalysis = $conn->query("SELECT COUNT(*) as total FROM fecalisys WHERE year = '$date' GROUP BY itr_no") or die(mysqli_error());
    $ffecalysis = $qfecalysis->fetch_array();
    // Sample data for the table
    $sample_data = array(
        array('id' => 1, 'labs' => 'Bio Lab', 'technician' => 'John Doe'),
        array('id' => 2, 'labs' => 'Physics Lab', 'technician' => 'Jane Smith'),
        // Add more data as needed...
    );
	$counter = 1;
?>
<html lang="eng">
    <head>
        <!-- Your existing head content... -->
        <title>Equipment Health Record Management System</title>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="shortcut icon" href="../images/logo.png" />
        <link rel="stylesheet" type="text/css" href="../css/bootstrap.css" />
        <link rel="stylesheet" type="text/css" href="../css/jquery.dataTables.css" />
        <link rel="stylesheet" type="text/css" href="../css/customize.css" />
        <?php require 'script.php' ?>
        <!-- <div style="text-align: center; padding-top: 5cm;">
            <img src="../images/home.png" style="display: flex; margin-left:480px; margin-bottom: 1000px" height="500px" /> ..............hello
        </div> -->
        <script src="../js/jquery.canvasjs.min.js"></script>
		<style>
			#content{
				padding-top: 70px;
			}
		</style>
    </head>
    <body>
        <div class="navbar navbar-default navbar-fixed-top">
            <!-- Your existing navbar code... -->
            <img src="../images/logo.png" style="float:left;" height="55px" /><label class="navbar-brand">Equipment Record Management System</label>
            <?php
            $q = $conn->query("SELECT * FROM admin WHERE admin_id = $_SESSION[admin_id]") or die(mysqli_error());
            $f = $q->fetch_array();
            ?>
            <ul class="nav navbar-right">
                <li class="dropdown">
                    <a class="user dropdown-toggle" data-toggle="dropdown" href="#">
                        <span class="glyphicon glyphicon-user"></span>
                        <?php
                        echo $f['firstname']." ".$f['lastname'];
                        ?>
                        <b class="caret"></b>
                    </a>
                    <ul class="dropdown-menu">
                        <li>
                            <a class="me" href="logout.php"><i class="glyphicon glyphicon-log-out"></i> Logout</a>
                        </li>
                    </ul>
                </li>
            </ul>
        </div>

        <div id="sidebar">
            <!-- Your existing sidebar code... -->
            <ul id="menu" class="nav menu">
    <li><a href="home.php?page=dashboard"><i class="glyphicon glyphicon-home"></i> Dashboard</a></li>
    <li><a href="#"><i class="glyphicon glyphicon-cog"></i> Accounts</a>
        <ul>
            <li><a href="admin.php"><i class="glyphicon glyphicon-cog"></i> Administrator</a></li>
            <li><a href="user.php"><i class="glyphicon glyphicon-cog"></i> User</a></li>
        </ul>
    </li>
    <li><a href="patient.php"><i class="glyphicon glyphicon-user"></i> Equipment</a></li>
    <li><a href="home.php?page=equipments"><i class="glyphicon glyphicon-folder-close"></i> Sections</a>
        <ul>
            <li><a href="fecalysis.php"><i class="glyphicon glyphicon-folder-open"></i> Bio lab</a></li>
            <li><a href = "maternity.php"><i class = "glyphicon glyphicon-folder-open"></i> Chemistry lab</a></li>
						<li><a href = "hematology.php"><i class = "glyphicon glyphicon-folder-open"></i> Physics lab</a></li>
						<li><a href = "dental.php"><i class = "glyphicon glyphicon-folder-open"></i> AR and VR lab</a></li>
						<li><a href = "xray.php"><i class = "glyphicon glyphicon-folder-open"></i> Electronics lab</a></li>
						<li><a href = "rehabilitation.php"><i class = "glyphicon glyphicon-folder-open"></i> Electrical lab</a></li>
						<li><a href = "sputum.php"><i class = "glyphicon glyphicon-folder-open"></i> Workshop and Mechanics lab</a></li>
						<li><a href = "urinalysis.php"><i class = "glyphicon glyphicon-folder-open"></i> civil lab</a></li>
            <!-- Add other section links as needed... -->
        </ul>
    </li>
    <li><a href="home.php?page=equipments"><i class="glyphicon glyphicon-cog"></i> Building Locations</a></li>
</ul>
        </div>
        <div id="content">
    <div class="container">
        <h2>Data :</h2>

        <?php
        // Check if the 'equipments' page is requested
        if (isset($_GET['page']) && $_GET['page'] == 'equipments') {
            // Fetch data from the location table
            $location_query = $conn->query("SELECT Building_id, Building_name,employee_name FROM location") or die(mysqli_error());
            $location_data = array();

            while ($row = $location_query->fetch_assoc()) {
                $location_data[] = $row;
            }
            ?>
            <table class="table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Building ID</th>
                        <th>Building Name</th>
                        <th>Employee Name</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    // Display the location data in the table
                    foreach ($location_data as $row) {
                        echo "<tr>";
                        echo "<td>$counter</td>";
                        echo "<td>{$row['Building_id']}</td>";
                        echo "<td>{$row['Building_name']}</td>";
                        echo "<td>{$row['employee_name']}</td>";
                        echo "</tr>";
                        $counter++;
                    }
                    ?>
                </tbody>
            </table>
        <?php
        } else {
            // Display the default content (user table)
            ?>
            <table class="table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Sections</th>
                        <th>Users</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    // Display the user data in the table
                    foreach ($user_data as $row) {
                        echo "<tr>";
                        echo "<td>$counter</td>";
                        echo "<td>{$row['section']}</td>"; // Assuming 'section' is the section column
                        echo "<td>{$row['username']}</td>"; // Assuming 'username' is the username column
                        echo "</tr>";
                        $counter++;
                    }
                    ?>
                </tbody>
            </table>
        <?php
        }
        ?>
    </div>
</div>


        <div id="footer">
            <!-- Your existing footer code... -->
            <label class="footer-title">&copy; Copyright  EQUIPMENT HEALTH RECORD MANAGEMENT SYSTEM 2020</label>
        </div>

    </body>
</html>