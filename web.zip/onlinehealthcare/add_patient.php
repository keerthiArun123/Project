<?php
	if(ISSET($_POST['save_patient'])){
		$itr_no = $_POST['itr_no'];
		$family_no = $_POST['family_no'];
		$firstname = $_POST['firstname'];
		$middlename = $_POST['middlename'];
		$lastname = $_POST['lastname'];
		$purchasedate = $_POST['month']."/".$_POST['day']."/".$_POST['year'];
		$age = $_POST['age'];
		$phil_health_no = $_POST['phil_health_no'];
		$address = $_POST['address'];
		$status = $_POST['status'];
		$Period = $_POST['Period'];
		$bp = $_POST['bp'];
		$temp = $_POST['temp']."&deg;C";
		$pr = $_POST['pr'];
		$rr = $_POST['rr'];
		$wt= $_POST['wt']."kg";
		$ht = $_POST['ht'];
		$conn = new mysqli("localhost", "root", "", "hcpms") or die(mysqli_error());
		$q1 = $conn->query("SELECT * FROM `itr` WHERE `itr_no` = '$itr_no'") or die(mysqli_error($conn));
		$c1 = $q1->num_rows;
		if($c1 > 0){
				echo "<script>alert('ITR No. must not be the same!')</script>";
		}else{
			$conn->query("INSERT INTO `itr` VALUES('$itr_no', '$family_no', '$phil_health_no', '$firstname', '$middlename', '$lastname', '$purchasedate', '$age', '$address', '$status', '$Period', '$bp', '$temp', '$pr', '$rr', '$wt', '".addslashes($ht)."')") or die(mysqli_error($conn));
			header("location: patient.php");	
		}
	}
	