<?php
// Include the database connection code here
include 'dbconfig.php';

if (isset($_GET['image_data'])) {
    $image_data = $_GET['image_data'];

    // Query your database to retrieve the image data or file path
    $sql = "SELECT Image FROM service_request WHERE service_id= ?";
    $stmt = $dbconn->prepare($sql);
    $stmt->bind_param("i", $image_data);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        $stmt->bind_result($image_data);
        $stmt->fetch();

        // Set appropriate headers for image display
        header("Content-Type: image/jpeg");
        
        // If your image data is stored as a BLOB, you can directly output it
        // echo $image_data;

        // If your image data is stored as a file path, you can read and display the image
        readfile($image_data);
    } else {
        echo "Image not found";
    }

    $stmt->close();
} else {
    echo "Image ID not provided";
}
?>