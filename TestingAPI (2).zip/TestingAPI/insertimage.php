<?php
require_once('dbconfig.php');

// Assuming you have form inputs named "equipment_id", "equipment_name", "problem_specification"
$equipment_id = $_POST['equipment_id'];
$equipment_name = $_POST['equipment_name'];
$problem_specification = $_POST['problem_specification'];
//$description = $_POST['description'];

// Insert data into the database
$sql = "INSERT INTO service_request (equipment_id, equipment_name, problem_specification)
        VALUES ('$equipment_id', '$equipment_name', '$problem_specification')";

// Perform the database query
if ($dbconn->query($sql) === TRUE) {
    // Data inserted successfully
    $response['status'] = true;
    $response['message'] = "Data added successfully";
} else {
    // Error in the database query
    $response['status'] = false;
    $response['message'] = "Error: " . $sql . "<br>" . $dbconn->error;
}

// Output JSON response
header('Content-Type: application/json');
echo json_encode($response);

// Close the database connection
$dbconn->close();
?>