<?php
// Include the database connection file
include 'dbconfig.php';

header("Content-Type: application/json");

// Retrieve all rows from the building_allocation table
$booking_query = "SELECT employee_name, Building_name FROM building_allocation";
$booking_result = $dbconn->query($booking_query);

if ($booking_result === false) {
    // Query failed, so display an error message
    http_response_code(500); // Internal Server Error
    echo json_encode(["error" => "Query error: " . $dbconn->error]);
} else {
    if ($booking_result->num_rows > 0) {
        $bookings = [];

        while ($row = $booking_result->fetch_assoc()) {
            $bookings[] = $row;
        }

        $data['data'] = $bookings; // Store all rows in the 'data' key
        echo json_encode($data);
    } else {
        http_response_code(404); // Not Found
        echo json_encode(["error" => "No booking records found in the database"]);
    }
}

// Close the database connection
$dbconn->close();
?>