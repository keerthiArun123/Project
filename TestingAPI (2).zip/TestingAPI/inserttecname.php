<?php
require_once('dbconfig.php');

// Check if the request is a POST request
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $service_id = $_POST['service_id']; // Change this line to use $_POST
    $employee_name = $_POST['employee_name'];
    $employee_id = $_POST['employee_id'];

    // Use the correct syntax for the UPDATE statement
    $updateData = "UPDATE service_request SET employee_name = '$employee_name', employee_id = '$employee_id' WHERE service_id = '$service_id'";

    $response = array();

    if(mysqli_query($dbconn, $updateData)){
        $response['status'] = 'success';
        $response['message'] = 'Update Successful';
    } else {
        $response['status'] = 'error';
        $response['message'] = 'Update Failed';
        // You can include an error message if needed
        // $response['error'] = mysqli_error($dbconn);
    }

    header('Content-Type: application/json; charset=UTF-8');
    echo json_encode($response);
} else {
    // Handle non-POST requests (e.g., return an error response)
    $response = array('status' => 'error', 'message' => 'Invalid request method.');
    header('Content-Type: application/json; charset=UTF-8');
    echo json_encode($response);
}
?>