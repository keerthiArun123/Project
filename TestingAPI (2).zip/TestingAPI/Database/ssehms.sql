-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 29, 2023 at 10:25 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ssehms`
--

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `registerid` varchar(50) NOT NULL,
  `bioid` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `department` varchar(50) NOT NULL,
  `location` varchar(50) NOT NULL,
  `rtype` varchar(50) NOT NULL,
  `roomno` varchar(50) NOT NULL,
  `address` varchar(100) NOT NULL,
  `duedate` date DEFAULT NULL,
  `attendance` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`registerid`, `bioid`, `username`, `password`, `department`, `location`, `rtype`, `roomno`, `address`, `duedate`, `attendance`) VALUES
('20230701', 10101, 'siva', 'pass123', 'CSE', 'Krishna', 'AC - 2S', 'A1230', '75, ADHITHANAR SALAI PUDUPET CHENNAI 600002', '2024-07-07', '78'),
('20230702', 10102, 'kumar', 'pass123', 'ECE', 'Krishna', 'AC - 4S', 'B120', 'NO. 63 C P RAMASWAMY ROAD ABHIRAMAPURAM 600018', '2023-07-10', '90'),
('20230703', 10103, 'Ram', 'pass123', 'BIO', 'Vaigai', 'NAC - 8S', 'C1230', '80 KAMARAJAR SALAI ANAKAPUTHUR CHENNAI 600070', '2024-07-24', '76'),
('20230704', 10104, 'kumaran', 'pass123', 'CIVIL', 'Krishna', 'NAC - 2S', 'D620', 'E 163 VII AVENUE BESANT NAGAR 600090', '2024-07-23', '94'),
('20230705', 10105, 'Gyaan', 'pass123', 'MECH', 'Krishna', 'NAC - 4S', 'G123', '18 K V KOIL STREET AYANAVARAM CHENNAI 600023', '2024-07-23', '99'),
('20230706', 10106, 'Gyaan', 'pass123', 'EEE', 'Vaigai', 'AC - 1S', 'A120', '812, PERIYAR E V R HIGH ROAD CHENNAI CHENNAI 600010', '2024-07-29', '57'),
('20230707', 10107, 'Gyaandeep', 'pass123', 'EEE', 'Krishna', 'AC - 8S', 'G128', 'NO.1, KALIAMMAN KOIL STREET, NATESAN NAGAR,VIRUGAMBAKKAM, CHENNAI - 600092', '2024-07-30', '99'),
('20230708', 10108, 'Ram', 'pass123', 'EEE', 'Vaigai', 'NAC - 4S', 'F123', '5/115 BAJANAI KOILST CONTONEMENT PALLAVARAM 600043', '2023-07-19', '99'),
('20230709', 10109, 'Vijayan', 'pass123', 'EEE', 'Krishna', 'AC - 1S', 'A434', 'NO.55 A SANTHOME HIGH RD SANTHOME 600028', '2024-07-09', '56'),
('20230710', 10110, 'Vijayan1', 'pass123', 'EEE1', 'Vaigai', 'NAC - 4S', 'A4342', '32/B VELACHERY MAIN ROAD VELACHERY CHENNAI 600042', '2024-07-22', '56');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`bioid`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
