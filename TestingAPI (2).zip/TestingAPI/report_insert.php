<?php error_reporting(0); ?> 
<?php
require_once('dbconfig.php');

/*$bioid = 10105;
$username = "Gyaan";
$password = "pass123";
$department = "MECH";
$attendance = "99";
$roomno = "G123";*/


//$u_id = "";
$equipment_name = "";
$equipment_id = "";
$status = "";
$lab_name= "";
$issued_date = "";

//$u_id  = $_GET['u_id'];
$equipment_name = $_GET['equipment_name'];
$status= $_GET['status'];
$equipment_id  = $_GET['equipment_id'];
$lab_name = $_GET['lab_name'];
$issued_date = $_GET['issued_date'];

//echo 'Bioid = ' .$bioid;
//echo 'username = '.$username;

/*$error;
if(empty($bioid)){
	
	$error = "Bioid is Required";
}

else if(empty($username)){
	
	$error = "username is Required";
}
else if(empty($password)){
	
	$error = "Password is Required";
}
else if(empty($department)){
	
	$error = "Department is Required";
}
else if(empty($attendance)){
	
	$error = "Attendance is Required";
}
else if(empty($roomno)){
	
	$error = "Room Number is Required";
}*/
 
	
	
	
	
	$insertData = "INSERT INTO service_request(equipment_name, status,equipment_id,lab_name,issued_date) VALUES('$equipment_name','$status','$equipment_id','$lab_name','$issued_date')";
	
	$qry =mysqli_query($dbconn,$insertData) or die (json_encode(array("status" => false, "message" => mysqli_error($dbconn)))); 
	
	if($qry){
		$id = mysqli_insert_id($dbconn);
		$response['status'] = true;
		$response['message']= "Resgister Successfully";
		//$response['u_id'] = $id;
	}
	else{
		
		$response['status'] = false;
		$response['message']= "Resgister Failed";
		
	}
	
	

	
header('Content-Type: application/json; charset=UTF-8');
echo json_encode($response);

?>