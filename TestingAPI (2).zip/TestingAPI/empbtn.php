<?php
require_once('dbconfig.php');

// Check if the request is a POST request
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $employee_name = $_POST['employee_name'];
    $equipment_id = $_POST['equipment_id'];

    $response = array();

    // Check if a record with the given equipment_id exists
    $checkQuery = "SELECT COUNT(*) FROM service_request WHERE equipment_id = '$equipment_id'";
    $result = mysqli_query($dbconn, $checkQuery);

    if ($result) {
        $row = mysqli_fetch_row($result);
        $recordCount = $row[0];

        if ($recordCount > 0) {
            // If the record exists, update the employee_name
            $updateData = "UPDATE service_request SET employee_name = '$employee_name' WHERE equipment_id = '$equipment_id'";

            if (mysqli_query($dbconn, $updateData)) {
                $response['status'] = 'success';
                $response['message'] = 'Data updated successfully';
            } else {
                $response['status'] = 'error';
                $response['message'] = 'Update Failed';
            }
        } else {
            // If the record doesn't exist, insert a new row
            $insertData = "INSERT INTO service_request (employee_name, equipment_id) VALUES ('$employee_name', '$equipment_id')";

            if (mysqli_query($dbconn, $insertData)) {
                $id = mysqli_insert_id($dbconn);
                $response['status'] = 'success';
                $response['message'] = 'Data inserted successfully';
                // You can include additional data in the response if needed
                // $response['u_id'] = $id;
            } else {
                $response['status'] = 'error';
                $response['message'] = 'Insert Failed';
            }
        }

        mysqli_free_result($result);
    } else {
        $response['status'] = 'error';
        $response['message'] = 'Query Failed';
    }

    header('Content-Type: application/json; charset=UTF-8');
    echo json_encode($response);
} else {
    // Handle non-POST requests (e.g., return an error response)
    $response = array('status' => 'error', 'message' => 'Invalid request method.');
    header('Content-Type: application/json; charset=UTF-8');
    echo json_encode($response);
}
?>