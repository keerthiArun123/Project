<?php error_reporting(0); ?> 
<?php
require_once('dbconfig.php');

//$bioid = "";
//$password = "";

//$bioid=$_GET['bioid'];
//$password=$_GET['password'];

$loginqry = "SELECT employee_name,employee_id,equipment_name,equipment_id,solved_date,issued_date,description,status  FROM service_table ";

$qry = mysqli_query($dbconn, $loginqry);

if(mysqli_num_rows($qry) > 0){
	
	$i =0;
	while($row = mysqli_fetch_assoc($qry)){
	$student[$i]['employee_id'] = $row['employee_id'];
	$student[$i]['employee_name'] = $row['employee_name'];
	$student[$i]['equipment_name'] = $row['equipment_name'];
	$student[$i]['equipment_id'] = $row['equipment_id'];
	$student[$i]['issued_date'] = $row['issued_date'];
	$student[$i]['solved_date'] = $row['solved_date'];
	$student[$i]['description'] = $row['description'];
	$student[$i]['status'] = $row['status'];
	/*$student[$i]['warranty_date'] = $row['warranty_date'];
	$student[$i]['warranty_period'] = $row['warranty_period'];
	$student[$i]['room'] = $row['room'];
	$student[$i]['floor'] = $row['floor'];
	$student[$i]['lab_name'] = $row['lab_name'];*/
	
	$i = $i+1;
	}
	//$userObj = mysqli_fetch_assoc($qry);
	$response['status'] = true;
	$response['message']= "Login Successfully";
	$response['data'] = $student;	
}
else{
	$response['status'] = false;
	$response['message']= "No Data";	
}
header('Content-Type: application/json; charset=UTF-8');
echo json_encode($response);
?>