<?php
require_once('con.php');

// Check if a user ID is provided in the query string
if (isset($_GET['userid'])) {
    $userid = $_GET['userid'];

    // Display uploaded images for the specified user ID
    $result = $conn->query("SELECT * FROM tn WHERE ei = '$userid'");
    
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $image_path = $row["image"];
            $userid = $row["Userid"];
            echo "<p>User ID: $userid</p>";
            echo "<img src='$image_path' alt='Uploaded Image' width='300'>";
        }
    } else {
        echo "No images found for User ID: $userid.";
    }
} else {
    echo "User ID not provided in the query string.";
}

// Close the database connection
$conn->close();
?>