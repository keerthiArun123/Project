<?php
require_once('dbconfig.php');

$loginqry = "SELECT delivery_date FROM service_table WHERE equipment_id = 'TD3T2' ";

$qry = mysqli_query($dbconn, $loginqry);

$response = [];

if ($qry) {
    $student = [];
    while ($row = mysqli_fetch_assoc($qry)) {
        $student[] = [
            'delivery_date' => $row['delivery_date'] !== null ? $row['delivery_date'] : 'N/A',
        ];
    }

    if (!empty($student)) {
        $response['status'] = true;
        $response['message'] = "Data Retrieved Successfully";
        $response['data'] = $student;
    } else {
        $response['status'] = false;
        $response['message'] = "No Data Available";
    }
} else {
    $response['status'] = false;
    $response['message'] = "Error in Query Execution: " . mysqli_error($dbconn);
}

header('Content-Type: application/json; charset=UTF-8');
echo json_encode($response);
?>