<?php
require_once('dbconfig.php');

// Check if the request is a POST request
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $equipment_name = $_POST['equipment_name'];
    $equipment_id = $_POST['equipment_id'];
    $lab_name = $_POST['lab_name'];
    $issued_date = $_POST['issued_date'];
    $problem_specification = $_POST['problem_specification'];
    //$other_details = $_POST['other_details'];

    $insertData = "INSERT INTO service_request(equipment_name, equipment_id, lab_name, issued_date,problem_specification) VALUES('$equipment_name', '$equipment_id', '$lab_name', '$issued_date','$problem_specification')";

    $response = array();

    if(mysqli_query($dbconn, $insertData)){
        $id = mysqli_insert_id($dbconn);
        $response['status'] = 'success';
        $response['message'] = 'Register Successfully';
        // You can include additional data in the response if needed
        // $response['u_id'] = $id;
    } else {
        $response['status'] = 'error';
        $response['message'] = 'Register Failed';
        // You can include an error message if needed
        // $response['error'] = mysqli_error($dbconn);
    }

    header('Content-Type: application/json; charset=UTF-8');
    echo json_encode($response);
} else {
    // Handle non-POST requests (e.g., return an error response)
    $response = array('status' => 'error', 'message' => 'Invalid request method.');
    header('Content-Type: application/json; charset=UTF-8');
    echo json_encode($response);
}
?>