<?php
$servername = "localhost";
$username = "root";
$password = "";
$database = "equipment";

// Establish a database connection
$conn = mysqli_connect($servername, $username, $password, $database);

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Check if the request method is POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get equipment_id from the POST data
    $equipment_id = isset($_POST['equipment_id']) ? trim($_POST['equipment_id']) : '';

    // Check if equipment_id is provided
    if ($equipment_id !== '') {
        // Check if the equipment ID and status match a service request in the "service_request" table
        $selectQuery = "SELECT * FROM service_request WHERE equipment_id = '$equipment_id' AND status = 'Not working'";
        $selectResult = mysqli_query($conn, $selectQuery);

        // Check if the SELECT query was successful
        if ($selectResult) {
            $request = mysqli_fetch_assoc($selectResult);

            // Check if a matching request was found
            if ($request) {
                // Update the status from "Not working" to "working"
                $updateQuery = "UPDATE service_request SET status = 'working' WHERE equipment_id = '$equipment_id' AND status = 'Not working'";
                $updateResult = mysqli_query($conn, $updateQuery);

                // Check if the UPDATE query was successful
                if ($updateResult) {
                    // Update the status from "working" to "completed"
                    $updateQuery = "UPDATE service_request SET status = 'completed' WHERE equipment_id = '$equipment_id' AND status = 'working'";
                    $updateResult = mysqli_query($conn, $updateQuery);

                    // Check if the UPDATE query was successful
                    if ($updateResult) {
                        // Set the status color based on the updated status
                        $statusColor = 'green';

                        // Return a JSON response with the updated status color
                        header('Content-Type: application/json');
                        echo json_encode(['status' => 'success', 'message' => 'Request completed successfully', 'status_color' => $statusColor]);
                    } else {
                        // Update query execution failed
                        echo json_encode(['status' => 'error', 'message' => 'Update query execution failed: ' . mysqli_error($conn)]);
                    }
                } else {
                    // Update query execution failed
                    echo json_encode(['status' => 'error', 'message' => 'Update query execution failed: ' . mysqli_error($conn)]);
                }
            } else {
                // Request not found or not in "Not working" status
                header('Content-Type: application/json', true, 400);
                echo json_encode(['status' => 'error', 'message' => 'Request not found or not in "Not working" status']);
            }
        } else {
            // Execution of the initial SELECT query failed
            echo json_encode(['status' => 'error', 'message' => 'Query execution failed: ' . mysqli_error($conn)]);
        }
    } else {
        // Invalid or missing parameters
        header('Content-Type: application/json', true, 400);
        echo json_encode(['status' => 'error', 'message' => 'Invalid or missing parameters']);
    }
} else {
    // Invalid request method
    header('Content-Type: application/json', true, 400);
    echo json_encode(['status' => 'error', 'message' => 'Invalid request method']);
}

// Close the database connection
mysqli_close($conn);
?>