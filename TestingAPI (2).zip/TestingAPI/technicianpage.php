<?php
// Remove error_reporting(0) if not needed for debugging

require_once('dbconfig.php');

// Assuming $employee_name is obtained from user input
$employee_name = isset($_GET['employee_name']) ? $_GET['employee_name'] : '';

// Use prepared statement to prevent SQL injection
$loginqry = "SELECT employee_name, employee_id, equipment_name, equipment_id, issued_date,lab_name, status FROM service_request WHERE employee_name = ?";
$stmt = mysqli_prepare($dbconn, $loginqry);

if ($stmt) {
    mysqli_stmt_bind_param($stmt, 's', $employee_name);
    mysqli_stmt_execute($stmt);

    $qry = mysqli_stmt_get_result($stmt);

    $response = array(); // Initialize the response array

    if ($qry) {
        $service_requests = array(); // Initialize the array

        if (mysqli_num_rows($qry) > 0) {
            while ($row = mysqli_fetch_assoc($qry)) {
                $service_request = array();
                $service_request['employee_name'] = $row['employee_name'];
                $service_request['employee_id'] = $row['employee_id'];
                $service_request['equipment_name'] = $row['equipment_name'];
                $service_request['equipment_id'] = $row['equipment_id'];
                $service_request['lab_name'] = $row['lab_name'];
                $service_request['issued_date'] = $row['issued_date'];
                $service_request['status'] = $row['status'];
                $service_requests[] = $service_request;
            }

            $response['status'] = true;
            $response['message'] = "Service requests found";
            $response['data'] = $service_requests;
        } else {
            $response['status'] = false;
            $response['message'] = "No service requests found for the given employee name";
        }
    } else {
        $response['status'] = false;
        $response['message'] = "Query execution error: " . mysqli_error($dbconn);
    }

    mysqli_stmt_close($stmt);
} else {
    $response['status'] = false;
    $response['message'] = "Failed to prepare the statement";
}

mysqli_close($dbconn);

header('Content-Type: application/json; charset=UTF-8');
echo json_encode($response);
?>