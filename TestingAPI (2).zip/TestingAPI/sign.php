<?php
$servername = "localhost";
$username = "root";
$password = "";
$database = "equipment";

// Establish a database connection
$dbconn = mysqli_connect($servername, $username, $password, $database);

// Check connection
if (!$dbconn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Check if the request method is POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get user details from the POST data
    $username = isset($_POST['employee_name']) ? trim($_POST['employee_name']) : '';
    $password = isset($_POST['password']) ? trim($_POST['password']) : '';
    $email = isset($_POST['email']) ? trim($_POST['email']) : '';

    // Check if all required fields are provided
    if ($username !== '' && $password !== '' && $email !== '') {
        // Check if the username is already taken
        $checkQuery = "SELECT * FROM signup WHERE employee_name = '$employee_name'";
        $checkResult = mysqli_query($dbconn, $checkQuery);

        // Check if the SELECT query was successful
        if ($checkResult) {
            if (mysqli_num_rows($checkResult) > 0) {
                // Username already exists
                header('Content-Type: application/json', true, 400);
                echo json_encode(['status' => 'error', 'message' => 'Username already exists']);
            } else {
                // Insert the user details into the signup table
                $insertQuery = "INSERT INTO signup (employee_name, password, email) VALUES ('$employee_name', '$password', '$email')";
                $insertResult = mysqli_query($dbconn, $insertQuery);

                // Check if the INSERT query was successful
                if ($insertResult) {
                    // Return a JSON response
                    header('Content-Type: application/json');
                    echo json_encode(['status' => 'success', 'message' => 'User registered successfully']);
                } else {
                    // Insert query execution failed
                    echo json_encode(['status' => 'error', 'message' => 'Insert query execution failed: ' . mysqli_error($conn)]);
                }
            }
        } else {
            // Execution of the initial SELECT query failed
            echo json_encode(['status' => 'error', 'message' => 'Query execution failed: ' . mysqli_error($dbconn)]);
        }
    } else {
        // Invalid or missing parameters
        header('Content-Type: application/json', true, 400);
        echo json_encode(['status' => 'error', 'message' => 'Invalid or missing parameters']);
    }
} else {
    // Invalid request method
    header('Content-Type: application/json', true, 400);
    echo json_encode(['status' => 'error', 'message' => 'Invalid request method']);
}

// Close the database connection
mysqli_close($dbconn);
?>