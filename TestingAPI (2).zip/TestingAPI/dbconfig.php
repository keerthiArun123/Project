<?php
$dbconn = mysqli_connect('localhost','root','','equipment');
if($dbconn){
//echo "Connection Sccessfully";
}
else{
die ("Connection Failed" . mysqli_connect_error());
}
?>