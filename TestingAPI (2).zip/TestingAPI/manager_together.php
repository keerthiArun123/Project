


<?php
// Include your database connection code here (e.g., db.php)
require_once('dbconfig.php');

// Get input parameters
$collegeName = $_POST['college_name'];
$employeeName = $_POST['employee_name']; // Assuming you're using POST


// Update the employee_name in the location table for the specified college
$updateQuery = "UPDATE location SET Building_name = ? WHERE employee_name = ?";
$updateStmt = $dbconn->prepare($updateQuery);
$updateStmt->bind_param("ss", $collegeName, $employeeName);

if ($updateStmt->execute()) {
    
    $response = array('status' => 'true', 'message'=>'Updated successfully');
    echo json_encode($response);
} else {
    echo "Error updating employee name: " . $dbconn->error;
}

$updateStmt->close();
$dbconn->close();
?>