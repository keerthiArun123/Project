<?php error_reporting(0); ?> 
<?php
require_once('dbconfig.php');

//$bioid = "";
//$password = "";

//$bioid=$_GET['bioid'];
$equipment_id=$_GET['equipment_id'];

$loginqry = "SELECT * FROM service_request WHERE status = 'Not working' OR status = 'working'";

$qry = mysqli_query($dbconn, $loginqry);

if(mysqli_num_rows($qry) > 0){
	
	$i =0;
	while($row = mysqli_fetch_assoc($qry)){
	$student[$i]['equipment_name'] = $row['equipment_name'];
	$student[$i]['equipment_id'] = $row['equipment_id'];
	$student[$i]['status'] = $row['status'];
	$student[$i]['lab_name'] = $row['lab_name'];
	$student[$i]['issued_date'] = $row['issued_date'];
	$student[$i]['solved_date'] = $row['solved_date'];
	$student[$i]['employee_name'] = $row['employee_name'];
	$student[$i]['employee_id'] = $row['employee_id'];
	$student[$i]['service_id'] = $row['service_id'];
    //$student[$i]['st2'] = $row['st2'];
    //$student[$i]['delivery_date'] = $row['delivery_date'];
	
    
	
	$i = $i+1;
	}
	//$userObj = mysqli_fetch_assoc($qry);
	$response['status'] = true;
	$response['message']= "Login Successfully";
	$response['data'] = $student;	
}
else{
	$response['status'] = false;
	$response['message']= "No Data";	
}
header('Content-Type: application/json; charset=UTF-8');
echo json_encode($response);
?>