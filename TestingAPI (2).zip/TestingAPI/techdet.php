<?php

// Include your database connection
include('dbconfig.php');

// Check if the database connection is successful
if (!$dbconn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Retrieve technician employees
$employeeQuery = "SELECT employee_name,employee_id FROM signup WHERE category = 'technician'";
$employeeResult = mysqli_query($dbconn, $employeeQuery);
$technicianEmployees = mysqli_fetch_all($employeeResult, MYSQLI_ASSOC);

// Retrieve all service requests
$equipmentQuery = "SELECT equipment_id, equipment_name FROM service_request";
$equipmentResult = mysqli_query($dbconn, $equipmentQuery);
$technicianEquipment = mysqli_fetch_all($equipmentResult, MYSQLI_ASSOC);

// Combine results into a single array
$response = [
    'technicianEmployees' => $technicianEmployees,
    'technicianEquipment' => $technicianEquipment,
];

// Output the JSON response
header('Content-Type: application/json');
echo json_encode($response);

// Close the database connection
mysqli_close($dbconn);
?>