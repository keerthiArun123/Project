<?php
$servername = "localhost";
$username = "root";
$password = "";
$database = "equipment";  // Include your database connection script
$conn = mysqli_connect($servername, $username, $password, $database);
if ($_SERVER['REQUEST_METHOD'] === 'POST')  {
    $equipment_id = $_POST['equipment_id'];
   // $studentId = $_POST['student_id'];
    //$date = $_POST['date'];

    // Check if there is a matching row with the given bus_id, student_id, and date in the "day_request" table
    $stmt = $conn->prepare("SELECT * FROM service_request WHERE equipment_id = ? AND status = 'Not working'");
    
    if ($stmt) {
        $stmt->bind_param('i', $equipment_id);
        
        if ($stmt->execute()) {
            $result = $stmt->get_result();
            $request = $result->fetch_assoc();
            
            if ($request) {
                // Update the status to "accepted"
                $updateStmt = $conn->prepare("UPDATE service_request SET status = 'working' WHERE equipment_id = ? AND status = 'Not working'");
                
                if ($updateStmt) {
                    $updateStmt->bind_param('i', $equipment_id);
                    
                    if ($updateStmt->execute()) {
                        // Return a JSON response
                        header('Content-Type: application/json');
                        echo json_encode(['status' => 'success', 'message' => 'Request accepted successfully']);
                    } else {
                        echo 'Update query execution failed: ' . $conn->error;
                    }
                } else {
                    echo 'Failed to prepare update query: ' . $conn->error;
                }
            } else {
                // Request not found or not in "pending" status
                header('Content-Type: application/json', true, 400);
                echo json_encode(['message' => 'Request not found or not in "pending" status']);
            }
        } else {
            // Execution of the initial query failed
            echo 'Query execution failed: ' . $conn->error;
        }
    } else {
        echo 'Failed to prepare query: ' . $conn->error;
    }
} else {
    // Invalid or missing parameters
    header('Content-Type: application/json', true, 400);
    echo json_encode(['message' => 'Invalid or missing parameters']);
}