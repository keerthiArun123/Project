<?php
// Database connection parameters
$servername = "localhost";
$username = "root";
$password = "";
$database = "equipment"; // Replace with your database name

// Create a connection
$conn = mysqli_connect($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle user profile data submission
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $employee_id = $_POST['employee_id'];
    $equipment_id = $_POST['equipment_id'];
    $equipment_name = $_POST['equipment_name'];
    $problem_specification= $_POST['problem_specification'];
    $status= $_POST['status'];



    // Handle image upload
    if (isset($_FILES['images  '])) {
        $image_data = file_get_contents($_FILES['images']['tmp_name']);
        $image_type = $_FILES['images']['type'];

        $sql = "INSERT INTO service_request ( employee_id,equipment_id,equipment_name,problem_specification, image_data, image_type) VALUES (?, ?, ?, ?, ?)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ssssss", $employee_id,$equipment_id, $equipment_name,$problem_specification, $image_data, $image_type);

        if ($stmt->execute()) {
            //echo "User profile created successfully.";
			$response['status']="true";
			$response['message']= " data inserted successfully";
				
        } else {
            //echo "Error: " . $stmt->error;
			$response['status']="false";
			$response['message']= " data inserting failed";
				
        }

        $stmt->close();
    } else {
        //echo "Image not uploaded.";
		$response['status']="false";
		$response['message']= "Image not uploaded";

    }
} else {
    echo "Invalid request method.";
	$response['status']="false";
	$response['message']= "Invalid request method.";
}
header('Content-Type: application/json; charset=UTF-8');
echo json_encode($response);
$conn->close();
?>


