<?php
// Include the database connection
require_once 'dbconfig.php';

// Get equipment ID, equipment name, and the specific date from the request
$data = json_decode(file_get_contents("php://input"), true);

if (isset($data["equipment_id"]) && isset($data["equipment_name"]) && isset($data["employee_name"]) && isset($data["employee_id"]) && isset($data["date_to_update"])) {
    $equipment_id = $data["equipment_id"];
    $equipment_name = $data["equipment_name"];
    $employee_name = $data["employee_name"];
    $employee_id = $data["employee_id"];
    $status = $data["status"];
    $date_to_update = $data["date_to_update"]; // The date provided by you

    // Validate the date format if needed
    if (!strtotime($date_to_update)) {
        $response = array("error" => "Invalid date format. Use YYYY-MM-DD HH:MM:SS");
        echo json_encode($response);
        exit();
    }

    // Update the row with the provided date
    $sql = "UPDATE service_request SET delivery_date = '$date_to_update' WHERE equipment_id = '$equipment_id' AND equipment_name = '$equipment_name'";

    if ($conn->query($sql) === TRUE) {
        $response = array("message" => "Equipment information updated successfully");
        echo json_encode($response);
    } else {
        $response = array("error" => "Error updating equipment information: " . $conn->error);
        echo json_encode($response);
    }
} else {
    $response = array("error" => "Missing required data. Ensure 'equipment_id', 'equipment_name', and 'date_to_update' are provided.");
    echo json_encode($response);
}

// Close the database connection
$dbconn->close();
?>