<?php
require_once('dbconfig.php'); // Include your database configuration

// Check if the HTTP request method is GET
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    // Query the database to get data where category is "Technician"
    $query = "SELECT employee_name,employee_id FROM signup WHERE Category = 'Technician'";
    $result = $dbconn->query($query);

    if ($result) {
        // Fetch and encode the data as JSON
        $data = $result->fetch_all(MYSQLI_ASSOC);
        header('Content-Type: application/json');
        echo json_encode(['data' => $data]);
    } else {
        // Handle database query error
        http_response_code(500); // Internal Server Error
        echo json_encode(['error' => 'Database query error']);
    }
} else {
    // Handle unsupported HTTP methods
    http_response_code(405); // Method Not Allowed
    echo json_encode(['error' => 'Method not allowed']);
}
?>