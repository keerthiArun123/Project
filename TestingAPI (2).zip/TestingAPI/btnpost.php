<?php
// Include the database connection file
include 'dbconfig.php';

// Check if the parameters are set in the URL
if(isset($_POST['employee_name']) && isset($_POST['Building_name'])) {
    // Retrieve data from the URL
    $employee_names = explode(",", $_POST['employee_name']);
    $Building_names = explode(",", $_POST['Building_name']);

    // Ensure the number of employee names and building names match
    if (count($employee_names) !== count($Building_names)) {
        echo "Error: Number of employee names and building names do not match.";
        exit();
    }

    // Insert the new data into the database
    for ($i=0; $i<count($employee_names); $i++) {
        $employee_name = $employee_names[$i];
        $Building_name = $Building_names[$i];
        
        $sql = "INSERT INTO building_allocation (employee_name, Building_name) VALUES ('$employee_name', '$Building_name')"; // Corrected column order

        if ($dbconn->query($sql) !== TRUE) {
            echo "Error: " . $sql . "<br>" . $dbconn->error;
            exit();
        }
    }

    $response = array('status' => 'success', 'message' => 'Data added successfully.');
    echo json_encode($response);
} else {
    echo "Error: Missing parameters in the URL.";
}

// Close the database connection
$dbconn->close();
?>