<?php

include 'dbconfig.php';

error_reporting(E_ALL);
ini_set('display_errors', 1);

$response = array(); // Initialize response array

// Get user inputs
$employee_name = mysqli_real_escape_string($dbconn, $_POST["employee_name"]);
$email = mysqli_real_escape_string($dbconn, $_POST["email"]);
$password = mysqli_real_escape_string($dbconn, $_POST["password"]);

// Validate inputs
if (empty($employee_name) || empty($email) || empty($password)) {
    $response['status'] = false;
    $response['message'] = "Please fill in all fields.";
} else {
    // Prepare and execute the query
    $loginqry = $dbconn->prepare("INSERT INTO signup(employee_name,email, password) VALUES ( ?, ?, ?)");
    $loginqry->bind_param("sss", $employee_name, $email, $password);
    $collabId = 0; // Replace with the actual value you want to use for CollabId    
    
    if ($loginqry->execute()) {
        $response['status'] = true;
        $response['message'] = "Signup Successfully";
    } else {
        $response['status'] = false;
        $response['message'] = "Signup Failed: " . $dbconn->error;
    }

    $loginqry->close(); // Close the prepared statement
}

// Send JSON response
header('Content-Type: application/json; charset=UTF-8');
echo json_encode($response);

?>