<?php error_reporting(0); ?> 
<?php
require_once('dbconfig.php');

//$bioid = "";
//$password = "";

//$bioid=$_GET['bioid'];
//$password=$_GET['password'];
//$building_name=$_GET['building_name'];

$loginqry = "SELECT * FROM location ";

$qry = mysqli_query($dbconn, $loginqry);

if(mysqli_num_rows($qry) > 0){
	
	$i =0;
	while($row = mysqli_fetch_assoc($qry)){
	$student[$i]['building_name'] = $row['Building_name'];
	$student[$i]['employee_name'] = $row['employee_name'];
	//$student[$i]['total_floor'] = $row['total_floor'];
    //$student[$i]['floor'] = $row['floor'];
    //$student[$i]['total_rooms'] = $row['total_rooms'];
    //$student[$i]['total_lab'] = $row['total_lab'];
	/*$student[$i]['status'] = $row['status'];
	$student[$i]['equipment_details'] = $row['equipment_details'];
	$student[$i]['purchase_date'] = $row['purchase_date'];
	$student[$i]['warranty_date'] = $row['warranty_date'];
	$student[$i]['warranty_period'] = $row['warranty_period'];
	$student[$i]['room'] = $row['room'];
	$student[$i]['floor'] = $row['floor'];
	$student[$i]['lab_name'] = $row['lab_name'];*/
	
	$i = $i+1;
	}
	//$userObj = mysqli_fetch_assoc($qry);
	$response['status'] = true;
	$response['message']= "Login Successfully";
	$response['data'] = $student;	
}
else{
	$response['status'] = false;
	$response['message']= "No Data";	
}
header('Content-Type: application/json; charset=UTF-8');
echo json_encode($response);
?>