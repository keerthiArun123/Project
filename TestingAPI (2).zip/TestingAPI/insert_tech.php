<?php error_reporting(0); ?> 
<?php
require_once('dbconfig.php');

/*$bioid = 10105;
$username = "Gyaan";
$password = "pass123";
$department = "MECH";
$attendance = "99";
$roomno = "G123";*/


//$u_id = "";
$employee_name = "";
//$equipment_id = "";



//$u_id  = $_GET['u_id'];
$employee_name = $_GET['employee_name'];


//echo 'Bioid = ' .$bioid;
//echo 'username = '.$username;

/*$error;
if(empty($bioid)){
	
	$error = "Bioid is Required";
}

else if(empty($username)){
	
	$error = "username is Required";
}
else if(empty($password)){
	
	$error = "Password is Required";
}
else if(empty($department)){
	
	$error = "Department is Required";
}
else if(empty($attendance)){
	
	$error = "Attendance is Required";
}
else if(empty($roomno)){
	
	$error = "Room Number is Required";
}*/
 
	
	
	
	
	$insertData = "INSERT INTO service_table(employee_name) VALUES('$employee_name')";
	
	$qry =mysqli_query($dbconn,$insertData) or die (json_encode(array("status" => false, "message" => mysqli_error($dbconn)))); 
	
	if($qry){
		$id = mysqli_insert_id($dbconn);
		$response['status'] = true;
		$response['message']= "Resgister Successfully";
		//$response['u_id'] = $id;
	}
	else{
		
		$response['status'] = false;
		$response['message']= "Resgister Failed";
		
	}
	
	

	
header('Content-Type: application/json; charset=UTF-8');
echo json_encode($response);

?>