<?php
// Database connection parameters
$servername = "localhost";
$username = "root";
$password = "";
$database = "equipment"; // Replace with your database name

// Create a connection
$dbconn = mysqli_connect($servername, $username, $password, $database);

// Check connection
if ($dbconn->connect_error) {
    die("Connection failed: " . $dbconn->connect_error);
}

// Handle user profile data submission
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $equipment_id = $_POST['equipment_id'];
    $equipment_name = $_POST['equipment_name'];
    $problem_specification= $_POST['problem_specification'];
    // Handle image upload
    if (isset($_FILES['images  '])) {
        $image_data = file_get_contents($_FILES['images']['tmp_name']);
        $image_type = $_FILES['images']['type'];

        $sql = "INSERT INTO service_request ( equipment_id,equipment_name,problem_specification, image_data, image_type) VALUES (?, ?, ?, ?, ?)";
        $stmt = $dbconn->prepare($sql);
        $stmt->bind_param("sssss", $equipment_id, $equipment_name,$problem_specification, $image_data, $image_type);

        if ($stmt->execute()) {
            //echo "User profile created successfully.";
			$response['status']="true";
			$response['message']= " data inserted successfully";
				
        } else {n
            //echo "Error: " . $stmt->error;
			$response['status']="false";
			$response['message']= " data inserting failed";
				
        }

        $stmt->close();
    } else {
        //echo "Image not uploaded.";
		$response['status']="false";
		$response['message']= "Image not uploaded";

    }
} else {
    echo "Invalid request method.";
	$response['status']="false";
	$response['message']= "Invalid request method.";
}
header('Content-Type: application/json; charset=UTF-8');
echo json_encode($response);
$dbconn->close();
?>


