<?php
require_once('dbconfig.php');
    // File upload handling
    $target_dir = "images/";  // Specify the directory where you want to store uploaded images
    $target_file = $target_dir . basename($_FILES["image"]["name"]);
    $uploadOk = 1;
    $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

    // Check if file already exists
    if (file_exists($target_file)) {
        echo "Sorry, file already exists.";
        $uploadOk = 1;
    }

    // Check file size
    if ($_FILES["image"]["size"] > 500000) {
        echo "Sorry, your file is too large.";
        $uploadOk = 0;
    }

    // Allow certain file formats
    if ($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg" && $imageFileType != "gif") {
        echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
        $uploadOk = 0;
    }

    // Check if $uploadOk is set to 0 by an error
    if ($uploadOk == 0) {
        echo "Sorry, your file was not uploaded.";
    } else {
        // If everything is ok, try to upload file
        if (move_uploaded_file($_FILES["image"]["tmp_name"], $target_file)) {
            // Insert the file path into the database
            $equipment_id = $_POST['equipment_id']; // Assuming you have a form input with the name "userid"
            $image_path = $target_file;
            $sql = "INSERT INTO service_request (equipment_id,equipment_name,problem_specification,image_data) VALUES ('$equipment_id','$equipment_name','$problem_specification', '$image_path')";
            
            if ($dbconn->query($sql) === TRUE) {
                echo "The file " . basename($_FILES["image"]["name"]) . " has been uploaded and inserted into the database.";
            } else {
                echo "Error: " . $sql . "<br>" . $dbconn->error;
            }
        } else {
            echo "Sorry, there was an error uploading your file.";
        }
    }

    // Close the database connection
    $dbconn->close();

?>