//
//  SupervisorEquApproveVC.swift
//  Equipment Health
//
//  Created by Karthik Babu on 29/09/23.
//

import UIKit

class SupervisorEquApproveVC: UIViewController {
    
    var image: Image!

    @IBOutlet weak var computer: UIView!
    @IBOutlet weak var callTech: UIView!
    override func viewDidLoad() {
        super.viewDidLoad()
        computer.layer.cornerRadius = 10
        callTech.layer.cornerRadius = 10
         

    }
    
    override func viewWillAppear(_ animated: Bool) {
        getImageAPI()
    }
    

    @IBAction func approve(_ sender: Any) {
        
        let nextVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "JobHistoryVC") as! JobHistoryVC
         self.navigationController?.pushViewController(nextVC, animated: true)    
    }
    
    func getImageAPI() {
        APIHandler().getAPIValues(type: Image.self
                                  , apiUrl: ServiceAPI.imageURL, method: "GET") { result in
            switch result {
            case .success(let data):
                self.image = data
                print(self.image.data ?? "")
                //print(self.image.data?.count ?? 0)
               
            case .failure(let error):
                print(error)
            }
        }
    }
    
}
