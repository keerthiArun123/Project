//
//  SupervisorHomeVC.swift
//  Equipment Health
//
//  Created by Karthik Babu on 29/09/23.
//

import UIKit

class SupervisorHomeVC: UIViewController {

    @IBOutlet weak var issues: UIButton!
    @IBOutlet weak var checkWeeKStatus: UIButton!
    @IBOutlet weak var notifyUser: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        issues.layer.cornerRadius = 10
        checkWeeKStatus.layer.cornerRadius = 10
        notifyUser.layer.cornerRadius = 10
    }
    
    @IBAction func workStatus(_ sender: Any) {
        
        let nextVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "SupervisorEquApproveVC") as! SupervisorEquApproveVC
         self.navigationController?.pushViewController(nextVC, animated: true)
    }
    
    @IBAction func issues(_ sender: Any) {
        let nextVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "JobHistoryVC") as! JobHistoryVC
         self.navigationController?.pushViewController(nextVC, animated: true)	
    }
    
    @IBAction func notifyUser(_ sender: Any) {
        let nextVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "NotifyUserVC") as! NotifyUserVC
         self.navigationController?.pushViewController(nextVC, animated: true)
        
    }
    
}
