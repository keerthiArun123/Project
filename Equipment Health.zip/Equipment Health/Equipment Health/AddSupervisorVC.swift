//
//  AddSupervisorVC.swift
//  Equipment Health
//
//  Created by Karthik Babu on 29/09/23.
//

import UIKit

class AddSupervisorVC: UIViewController {
    
    @IBOutlet weak var phoneTf: UITextField!
    
    @IBOutlet weak var empName: UITextField!
    @IBOutlet weak var empID: UITextField!
    @IBOutlet weak var empDesignation: UITextField!
    @IBOutlet weak var emailTF: UITextField!
    @IBOutlet weak var otherDetails: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    @IBAction func addAction(_ sender: Any) {
        self.EquipAPI()
    }
    
    func EquipAPI() {
            let formData: [String: String] = [
                "employee_name": empName.text ?? "",
                "employee_id": empID.text ?? "",
                "Category": empDesignation.text ?? "",
                "email": emailTF.text ?? "",
                "phn_num": phoneTf.text ?? "",
                "other_details": otherDetails.text ?? ""
                /*"Designation": designationTextField.text ?? "",
                "contact_no": numberTextField.text ?? "",
                "Address": AddressTextField.text ?? "",
                "blood_group": bloodgroupTextField.text ?? ""*/
                
            ]
        APIHandler().postAPIValues(type: Employee.self, apiUrl: ServiceAPI.employeeURL, method: "POST", formData: formData) { result in
                switch result {
                case .success(let response):
                    print("Status: \(response.status ?? "")")
                    print("Message: \(response.message ?? "")")
                    DispatchQueue.main.async {
                       print(formData)
                    }
                case .failure(let error):
                    print("Error: \(error)")
                }
            }
        }
}
