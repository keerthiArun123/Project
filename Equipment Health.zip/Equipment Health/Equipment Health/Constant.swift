//
//  Constant.swift
//  WeatherApp
//
//  Created by MAC-Air on 08/09/23.
//

import Foundation
import UIKit

struct ServiceAPI {
    static let baseURL = "http://192.168.174.94//"
    static let loginURL = baseURL+"testingAPI/loginGet.php?"
    static let signUp = baseURL+"testingAPI/signup.php?" //username=ram&password=ram&user_id=121&email=ram@gmail.com"
    static let equipmentURL = baseURL+"testingAPI/getalldata.php"
    static let totalURL = baseURL+"testingAPI/equipment_Details.php?" //equipment_id=TD2S199"
    static let statussURL = baseURL+"testingAPI/notifystatusextract.php?"//equipment_id=TD2S199"
    static let healthURL = baseURL+"testingAPI/data.php"
    static let reportURL = baseURL+"testingAPI/report.php?" //equipment_id=TD2S199"
    static let imageURL = baseURL+"testingAPI/getimage.php"
    static let completedURL = baseURL+"testingAPI/completed.php?"
    static let buildingURL = baseURL+"testingAPI/Buildings.php?"
    static let floorURL = baseURL+"testingAPI/floor.php?"
    static let allocatedURL = baseURL+"testingAPI/technicianpage.php?"
    static let addEmployee = baseURL+"testingAPI/registration.php?"
    static let equipURL = baseURL+"testingAPI/addequip.php?"
    static let employeeURL = baseURL+"testingAPI/register.php?"
    static let supervisorURL = baseURL+"testingAPI/getemp.php?"
    static let collegeURL = baseURL+"testingAPI/college.php?"
    static let supbuildURL = baseURL+"testingAPI/Allocated.php?"
    static let NoteURL = baseURL+"testingAPI/duplicate.php?"
    static let AddlabURL = baseURL+"testingAPI/labadd.php?"
    static let AddbuildURL = baseURL+"testingAPI/addbuild.php?"
    static let ManaempURL = baseURL+"testingAPI/emppost.php?"
    static let ManabuildURL = baseURL+"testingAPI/buildpost.php?"
    static let ProblemdetailsURL = baseURL+"testingAPI/reportproblem.php?"
    static let StateURL = baseURL+"testingAPI/techstate.php?"
    static let WorkstatusURL = baseURL+"testingAPI/acceptbtn.php?"
    static let PostbtnURL = baseURL+"testingAPI/manager_together.php?"
    static let technician = baseURL+"testingAPI/postbtn.php?"
    static let techDetails = baseURL+"testingAPI/techdet.php"
    static let reportDetails = baseURL+"testingAPI/getreport.php"
    static let TechnicianURL = baseURL+"testingAPI/Technician.php"
    static let insertTechURL = baseURL+"testingAPI/inserttecname.php?"
    static let NotificationURL = baseURL+"testingAPI/techwork.php"
    static let acceptURL = baseURL+"testingAPI/accept.php?"
    static let rejectURL = baseURL+"testingAPI/reject.php?"
    static let LabgetURL = baseURL+"testingAPI/labget.php?"
}
