//
//  ViewController.swift
//  Equipment Health
//
//  Created by SAIL on 19/09/23.
//

import UIKit

class ViewController: UIViewController {
    

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

