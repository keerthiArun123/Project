//
//  JobHistoryVC.swift
//  Equipment Health
//
//  Created by SAIL on 29/09/23.
//

import UIKit

class JobHistoryVC: UIViewController {

    
 
    @IBOutlet weak var segmentAC: UISegmentedControl!
    
    @IBOutlet weak var jobListTable: UITableView!
    
    var completed: Completed!
    var tecnician: TechniciansModel!
    var post: Postbtn!
    
    var isTechSelected: Bool = false
    var nSelectedSegmentIndex : Int = 1

    var techName = ""
    var JobID = ""
    var serviceID = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        jobListTable.dataSource = self
        jobListTable.delegate = self
//        segmentAC.addAction(for: .tap) {
//            self.jobListTable.reloadData()
//        }
       
    }
    override func viewWillAppear(_ animated: Bool) {
        getCompletedAPI()
        getTechAPI()
  }
    
    @IBAction func segmentAction(_ sender: Any) {
        switch segmentAC.selectedSegmentIndex {
        case 0:
            self.nSelectedSegmentIndex = 1
            getCompletedAPI()
        case 1:
            self.nSelectedSegmentIndex = 2
            getCompletedAPI()
        default:
            break
        }
        jobListTable.reloadData()
        
    }
    
    @objc func getTechAPI() {
        APIHandler().getAPIValues(type: TechniciansModel.self
                                  , apiUrl: ServiceAPI.TechnicianURL, method: "GET") { result in
            switch result {
            case .success(let data):
                self.tecnician = data
//                if completed.data[].status
                DispatchQueue.main.async {
//                    if let technicianData = self.tecnician?.data as? [String] {
//                        AlertManager.showAction(
//                            title: "Select Technician",
//                            message: "",
//                            options: technicianData,
//                            viewController: self,
//                            completionHandler: { selectedTechnician in
//                                // Your completion handler code here
//                                
//                            }
//                        )
//                    }
                }
            case .failure(let error):
                print(error)
            }
        }
    }
    
    func InsertTechPostAPI(serviceID: String) {
        
        let formData = ["employee_name":self.techName, "employee_id":self.JobID, "service_id":serviceID]
        
        APIHandler().postAPIValues(type: Postbtn.self, apiUrl: ServiceAPI.insertTechURL, method: "POST", formData: formData) { result in
            switch result {
            case .success(let response):
                print(response.status ?? "")
                print(response.message ?? "")
                DispatchQueue.main.async {
                    self.jobListTable.reloadData()
                    self.getCompletedAPI()
                }
            case .failure(let error):
                print(error)
            }
        }
    }
    
    func getCompletedAPI() {
        APIHandler().getAPIValues(type: Completed.self
                                  , apiUrl: ServiceAPI.completedURL, method: "GET") { result in
            switch result {
            case .success(let data):
                self.completed = data
//                if completed.data[].status
                print(self.completed.data ?? "")
                print(self.completed.data?.count ?? 0)
                DispatchQueue.main.async {
                    self.jobListTable.reloadData()
                }
            case .failure(let error):
                print(error)
            }
        }
    }
    
}

extension JobHistoryVC : UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        guard let supervisorHomeData = completed, let jobs = supervisorHomeData.data else {
            return 0
        }
        
        if nSelectedSegmentIndex == 1 {
            // Count the number of "Not working" jobs
            return jobs.filter { $0.status == "Not working" }.count
        } else if nSelectedSegmentIndex == 2 {
            // Count the number of "working" jobs
            return jobs.filter { $0.status == "working" }.count
        }
        
        return 0 // Handle other cases as needed
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "JobHistoryCell", for: indexPath) as! JobHistoryCell
        
        guard let supervisorHomeData = completed, let jobs = supervisorHomeData.data else {
            return cell
        }

        let job = jobs[indexPath.row]

        if nSelectedSegmentIndex == 1 {
            
//        } && job.status == "Not working" {
            let notWorking = jobs.filter{ $0.status == "Not working" }
            cell.dropDown.isHidden = false
            cell.dropDown.tag = indexPath.row
            cell.dropDown.addTarget(self, action: #selector(DropDownAction), for: .touchUpInside)

            
            if indexPath.row < notWorking.count {
                let job = notWorking[indexPath.row]

                // Add your logic here to customize the cell for each "Pending" job
                cell.equipmentNameLbl.text = "Equipment Name : \(job.equipmentName ?? "")"
                cell.idNoLbl.text = "Equipment ID : \(job.equipmentID ?? "")"
                cell.kitStatusLbl.text = "Status : \(job.status ?? "")"
                cell.labLocationlbl.text = "Lab Name : \(job.labName ?? "")"
                cell.dateLbl.text = "Date : \(job.issuedDate ?? "")"
                cell.tech.text = "Technician: \(job.employeeName ?? "")"
                cell.jobId.text = "Job Id: \(job.employeeID ?? "")"
                
                self.serviceID = job.serviceID ?? ""
            }
            // Display data for "Not working" status
        
        } else if nSelectedSegmentIndex == 2 {
            cell.dropDown.isHidden = true
        //} && job.status == "working" {
            let notWorking = jobs.filter{ $0.status == "working" }
            if indexPath.row < notWorking.count {
                let job = notWorking[indexPath.row]

                // Add your logic here to customize the cell for each "Pending" job
                cell.equipmentNameLbl.text = "Equipment Name : \(job.equipmentName ?? "")"
                cell.idNoLbl.text = "Equipment ID : \(job.equipmentID ?? "")"
                cell.kitStatusLbl.text = "Status : \(job.status ?? "")"
                cell.labLocationlbl.text = "Lab Name : \(job.labName ?? "")"
                cell.dateLbl.text = "Date : \(job.issuedDate ?? "")"
            }
        } else {
            // Handle other cases or do nothing
        }

        if job.employeeName == "" {
            cell.tech.isHidden = true
            cell.jobId.isHidden = true
        } else {
            cell.tech.isHidden = false
            cell.jobId.isHidden = false
        }

        return cell
    }



    @objc func DropDownAction(sender: UIButton) {
        let indexPath = IndexPath(row: sender.tag, section: 0)

        // Check if technician data is available
        guard let technicians = self.tecnician.data else {
            // Handle the case where technician data is nil
            print("Technician data is nil.")
            return
        }

        // Fetch the selected job based on the index path
        guard let selectedJob = getSelectedJob(indexPath: indexPath) else {
            // Handle the case where the selected job is nil
            print("Selected job is nil.")
            return
        }

        let sheet = UIAlertController(title: "Technicians", message: nil, preferredStyle: .actionSheet)

        // Create an action for each technician
        for technician in technicians {
            sheet.addAction(UIAlertAction(title: technician.employeeName, style: .default) { _ in
                // Handle the selected technician
                self.techName = technician.employeeName ?? ""
                self.JobID = technician.employeeID ?? ""
                self.isTechSelected = true

                // Access the serviceID directly from the selected job
                let serviceID = selectedJob.serviceID ?? ""
                
                // Pass the service ID to InsertTechPostAPI
                self.InsertTechPostAPI(serviceID: serviceID)
            })
        }

        sheet.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
        present(sheet, animated: true)
    }

    func getSelectedJob(indexPath: IndexPath) -> CompletedData? {
        guard let supervisorHomeData = completed, let jobs = supervisorHomeData.data else {
            return nil
        }

        switch nSelectedSegmentIndex {
        case 1:
            let notWorking = jobs.filter { $0.status == "Not working" }
            if indexPath.row < notWorking.count {
                return notWorking[indexPath.row]
            }
        case 2:
            // Handle other segments or do nothing
            break
        default:
            break
        }

        return nil
    }

}


