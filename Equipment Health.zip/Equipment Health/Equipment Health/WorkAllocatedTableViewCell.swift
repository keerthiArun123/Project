//
//  WorkAllocatedTableViewCell.swift
//  Equipment Health
//
//  Created by SAIL on 14/10/23.
//

import UIKit

class WorkAllocatedTableViewCell: UITableViewCell {
    
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var idLabel: UILabel!
    @IBOutlet weak var statuslabel: UILabel!
    @IBOutlet weak var labLabel: UILabel!
    @IBOutlet weak var dateLabel: UILabel!
    @IBOutlet weak var technicianLabel: UILabel!
    @IBOutlet weak var jobIdLaebl: UILabel!
    @IBOutlet weak var dropDownButton: UIButton!
    
    

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
