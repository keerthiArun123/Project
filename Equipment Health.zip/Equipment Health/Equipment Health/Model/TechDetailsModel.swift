//
//  TechDetailsModel.swift
//  Equipment Health
//
//  Created by Haris Madhavan on 24/11/23.
//

import Foundation

// MARK: - TechDetailsModel
struct TechDetailsModel: Codable {
    var technicianEmployees: [TechnicianEmployee]?
    var technicianEquipment: [TechnicianEquipment]?
}

// MARK: - TechnicianEmployee
struct TechnicianEmployee: Codable {
    var employeeName, employeeID: String?

    enum CodingKeys: String, CodingKey {
        case employeeName = "employee_name"
        case employeeID = "employee_id"
    }
}

// MARK: - TechnicianEquipment
struct TechnicianEquipment: Codable {
    var equipmentID, equipmentName: String?

    enum CodingKeys: String, CodingKey {
        case equipmentID = "equipment_id"
        case equipmentName = "equipment_name"
    }
}
