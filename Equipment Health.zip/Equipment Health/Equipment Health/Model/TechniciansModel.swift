//
//  TechniciansModel.swift
//  Equipment Health
//
//  Created by Haris Madhavan on 25/11/23.
//

import Foundation

// MARK: - TechnicianModel
struct TechniciansModel: Codable {
    var status: Bool?
    var message: String?
    var data: [Tech]?
}

// MARK: - Datum
struct Tech: Codable {
    var employeeID, employeeName: String?

    enum CodingKeys: String, CodingKey {
        case employeeID = "employee_id"
        case employeeName = "employee_name"
    }
}
