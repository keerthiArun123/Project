//
//  EquipmentsModel.swift
//  Equipment Health
//
//  Created by SAIL on 10/10/23.
//

import Foundation

// MARK: - Welcome
struct Equipments: Codable {
    var status: Bool?
    var message: String?
    var data: [EquipmentData]?
}

// MARK: - Datum
struct EquipmentData: Codable {
    var equipmentID, equipmentName, status, features: String?
    var purchaseDate, warrantyPeriod, warrantyendDate, room: String?
    var floor, labName: String?
    var image: String?

    enum CodingKeys: String, CodingKey {
        case equipmentID = "equipment_id"
        case equipmentName = "equipment_name"
        case status, features
        case purchaseDate = "purchase_date"
        case warrantyPeriod = "warranty_period"
        case warrantyendDate = "warrantyend_date"
        case room, floor
        case labName = "lab_name"
        case image
    }
}
