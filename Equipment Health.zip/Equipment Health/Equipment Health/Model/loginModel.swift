//
//  login.swift
//  Equipment Health
//
//  Created by SAIL on 10/10/23.
//

import Foundation

// MARK: - Welcome
struct LoginModel: Codable {
    var status: Bool?
    var message: String?
    var data: LoginModelData?
}

// MARK: - DataClass
struct LoginModelData: Codable {
    var uID, did, username, password: String?
    var category, userID, email: String?

    enum CodingKeys: String, CodingKey {
        case uID = "u_id"
        case did = "Did"
        case username, password
        case category = "Category"
        case userID = "user_id"
        case email
    }
}
