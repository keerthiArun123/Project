//
//  GetReportModel.swift
//  Equipment Health
//
//  Created by Haris Madhavan on 25/11/23.
//

import Foundation

// MARK: - GetReportModel
struct GetReportModel: Codable {
    var status: Bool?
    var message: String?
    var data: [GetReport]?
}

// MARK: - Datum
struct GetReport: Codable {
    var equipmentID, equipmentName, labName: String?

    enum CodingKeys: String, CodingKey {
        case equipmentID = "equipment_id"
        case equipmentName = "equipment_name"
        case labName = "lab_name"
    }
}
