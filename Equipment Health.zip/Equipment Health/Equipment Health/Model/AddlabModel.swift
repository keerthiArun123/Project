//
//  AddfloorModel.swift
//  Equipment Health
//
//  Created by SAIL on 17/10/23.
//
 
import Foundation

// MARK: - Welcome
struct Addlab: Codable {
    var status, message: String?
}

