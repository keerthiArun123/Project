//
//  CollegeModel.swift
//  Equipment Health
//
//  Created by SAIL on 17/10/23.
//

import Foundation

// MARK: - Welcome
struct College: Codable {
    var status: Bool?
    var message: String?
    var data: [CollegeData]?
}

// MARK: - Datum
struct CollegeData: Codable {
    var buildingName: String?

    enum CodingKeys: String, CodingKey {
        case buildingName = "building_name"
    }
}
