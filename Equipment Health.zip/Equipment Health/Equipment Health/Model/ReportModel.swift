//
//  ReportModel.swift
//  Equipment Health
//
//  Created by SAIL on 11/10/23.
//


import Foundation

// MARK: - Welcome
struct Report: Codable {
    var status: Bool?
    var message: String?
    var data: [ReportData]?
}

// MARK: - Datum
struct ReportData: Codable {
    var equipmentID, equipmentName, labName, problemDescription: String?
    var status, issuedDate: String?

    enum CodingKeys: String, CodingKey {
        case equipmentID = "equipment_id"
        case equipmentName = "equipment_name"
        case labName = "lab_name"
        case problemDescription = "problem_description"
        case status
        case issuedDate = "issued_date"
    }
}
