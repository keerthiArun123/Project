//
//  totaldataModel.swift
//  Equipment Health
//
//  Created by SAIL on 10/10/23.
//

import Foundation

// MARK: - Welcome
struct Totaldata: Codable {
    var status: Bool?
    var message: String?
    var data: [totaldataData]?
}

// MARK: - Datum
struct totaldataData: Codable {
    var equipmentID, equipmentName, status, features: String?
    var purchaseDate, warrantyendDate, warrantyPeriod, servicesUndergone: String?
    var totalServices, price: String?
    var image: String?

    enum CodingKeys: String, CodingKey {
        case equipmentID = "equipment_id"
        case equipmentName = "equipment_name"
        case status, features
        case purchaseDate = "purchase_date"
        case warrantyendDate = "warrantyend_date"
        case warrantyPeriod = "warranty_period"
        case servicesUndergone = "services_undergone"
        case totalServices = "total_services"
        case price
        case image
    }
}

