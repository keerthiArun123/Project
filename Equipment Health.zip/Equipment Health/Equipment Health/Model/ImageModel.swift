//
//  ImageModel.swift
//  Equipment Health
//
//  Created by SAIL on 12/10/23.
//

import Foundation

// MARK: - Welcome
struct Image: Codable {
    var status: Bool?
    var message: String?
    var data: ImageDataClass?
}

// MARK: - DataClass
struct ImageDataClass: Codable {
    var the1: The1?

    enum CodingKeys: String, CodingKey {
        case the1 = "1"
    }
}

// MARK: - The1
struct The1: Codable {
    var equipmentID, equipmentName, problemSpecification, imageType: String?
    var imageData: String?

    enum CodingKeys: String, CodingKey {
        case equipmentID = "equipment_id"
        case equipmentName = "equipment_name"
        case problemSpecification = "problem_specification"
        case imageType = "image_type"
        case imageData = "image_data"
    }
}
