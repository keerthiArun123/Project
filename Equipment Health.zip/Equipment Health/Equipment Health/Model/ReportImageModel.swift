//
//  ReportImageModel.swift
//  Equipment Health
//
//  Created by Haris Madhavan on 23/11/23.
//

import Foundation

// MARK: - ReportModel
struct ReportModel: Codable {
    var status, message: String?
}
