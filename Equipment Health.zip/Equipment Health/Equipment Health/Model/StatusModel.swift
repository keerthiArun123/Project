//
//  StatusModel.swift
//  Equipment Health
//
//  Created by SAIL on 11/10/23.
//

import Foundation

// MARK: - Welcome
struct Statuss: Codable {
    var status: Bool?
    var message: String?
    var data: [StatussData]?
}

// MARK: - Datum
struct StatussData: Codable {
    var equipmentID, equipmentName, deliveryDate: String?

    enum CodingKeys: String, CodingKey {
        case equipmentID = "equipment_id"
        case equipmentName = "equipment_name"
        case deliveryDate = "delivery_date"
    }
}
