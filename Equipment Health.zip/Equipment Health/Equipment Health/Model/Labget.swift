//
//  Labget.swift
//  Equipment Health
//
//  Created by SAIL on 21/12/23.
//


import Foundation

// MARK: - Welcome
struct LabgetModel: Codable {
    var status: Bool?
    var message: String?
    var data: [Datum]?
}

// MARK: - Datum
struct Datum: Codable {
    var labName: String?

    enum CodingKeys: String, CodingKey {
        case labName = "lab_name"
    }
}
