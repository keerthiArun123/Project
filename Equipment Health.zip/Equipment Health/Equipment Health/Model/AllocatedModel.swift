//
//  AllocatedModel.swift
//  Equipment Health
//
//  Created by SAIL on 13/10/23.
//

// This file was generated from JSON Schema using quicktype, do not modify it directly.
// To parse the JSON, add this file to your project and do:
//
//   let welcome = try? JSONDecoder().decode(Welcome.self, from: jsonData)

import Foundation

// MARK: - Welcome
struct Allocated: Codable {
    var status: Bool?
    var message: String?
    var data: [AllocatedData]?
}

// MARK: - Datum
struct AllocatedData: Codable {
    var employeeName, employeeID, equipmentName, equipmentID: String?
        var labName, issuedDate, status: String?

        enum CodingKeys: String, CodingKey {
            case employeeName = "employee_name"
            case employeeID = "employee_id"
            case equipmentName = "equipment_name"
            case equipmentID = "equipment_id"
            case labName = "lab_name"
            case issuedDate = "issued_date"
            case status
        }
    }
