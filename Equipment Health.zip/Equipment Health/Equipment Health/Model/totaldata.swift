
// This file was generated from JSON Schema using quicktype, do not modify it directly.
// To parse the JSON, add this file to your project and do:
//
//   let welcome = try? JSONDecoder().decode(Welcome.self, from: jsonData)

import Foundation

// MARK: - Welcome
struct total: Codable {
    var status: Bool?
    var message: String?
    var data: [totalData]?
}

// MARK: - Datum
struct Datum: Codable {
    var equipmentID, equipmentName, status, features: String?
    var purchaseDate, warrantyendDate, warrantyPeriod, servicesUndergone: String?
    var totalServices, price: String?

    enum CodingKeys: String, CodingKey {
        case equipmentID = "equipment_id"
        case equipmentName = "equipment_name"
        case status, features
        case purchaseDate = "purchase_date"
        case warrantyendDate = "warrantyend_date"
        case warrantyPeriod = "warranty_period"
        case servicesUndergone = "services_undergone"
        case totalServices = "total_services"
        case price
    }
}
