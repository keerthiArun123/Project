//
//  HealthModel.swift
//  Equipment Health
//
//  Created by SAIL on 11/10/23.
//

import Foundation

// MARK: - Welcome
struct Health: Codable {
    var status: Bool?
    var message: String?
    var data: [HealthData]?
}

// MARK: - Datum
struct HealthData: Codable {
    var equipmentID, equipmentName, status, features: String?
    var purchaseDate, warrantyPeriod, warrantyendDate, room: String?
    var floor, labName: String?

    enum CodingKeys: String, CodingKey {
        case equipmentID = "equipment_id"
        case equipmentName = "equipment_name"
        case status, features
        case purchaseDate = "purchase_date"
        case warrantyPeriod = "warranty_period"
        case warrantyendDate = "warrantyend_date"
        case room, floor
        case labName = "lab_name"
    }
}

