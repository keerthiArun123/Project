//
//  UserModel.swift
//  Equipment Health
//
//  Created by SAIL on 11/10/23.
//

import Foundation
// This file was generated from JSON Schema using quicktype, do not modify it directly.
// To parse the JSON, add this file to your project and do:
//
//   let welcome = try? JSONDecoder().decode(Welcome.self, from: jsonData)


// MARK: - Welcome
struct User: Codable {
    var status: Bool?
    var message: String?
    var data: [UserData]?
}

// MARK: - Datum
struct UserData: Codable {
    var equipmentID, equipmentName, deliveryDate: String?

    enum CodingKeys: String, CodingKey {
        case equipmentID = "equipment_id"
        case equipmentName = "equipment_name"
        case deliveryDate = "delivery_date"
    }
}



