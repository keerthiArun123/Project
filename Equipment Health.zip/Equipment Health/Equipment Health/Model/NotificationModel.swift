//
//  NotificationModel.swift
//  Equipment Health
//
//  Created by Haris Madhavan on 27/11/23.
//

import Foundation

// MARK: - NotificationModel
struct NotificationModel: Codable {
    var status: Bool?
    var message: String?
    var data: [Notify]?
}

// MARK: - Datum
struct Notify: Codable {
    var employeeID, employeeName, equipmentName, equipmentID: String?
    var issuedDate, solvedDate, descriptions, status: String?

    enum CodingKeys: String, CodingKey {
        case employeeID = "employee_id"
        case employeeName = "employee_name"
        case equipmentName = "equipment_name"
        case equipmentID = "equipment_id"
        case issuedDate = "issued_date"
        case solvedDate = "solved_date"
        case descriptions = "description"
        case status
    }
}
