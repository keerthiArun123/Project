//
//  StateModel.swift
//  Equipment Health
//
//  Created by SAIL on 30/10/23.
//

import Foundation

// MARK: - Welcome
struct State: Codable {
    var status, message: String?
}
