//
//  CompletedModel.swift
//  Equipment Health
//
//  Created by SAIL on 12/10/23.
//

// This file was generated from JSON Schema using quicktype, do not modify it directly.
// To parse the JSON, add this file to your project and do:
//
//   let welcome = try? JSONDecoder().decode(Welcome.self, from: jsonData)

// This file was generated from JSON Schema using quicktype, do not modify it directly.
// To parse the JSON, add this file to your project and do:
//
//   let welcome = try? JSONDecoder().decode(Welcome.self, from: jsonData)

import Foundation

//// MARK: - Welcome
//struct Completed: Codable {
//    var status: Bool?
//    var message: String?
//    var data: [CompletedData]?
//}
//
//// MARK: - Datum
//struct CompletedData: Codable {
//    var equipmentName, equipmentID, status, labName: String?
//    var employeeID, issuedDate, solvedDate, employeeName: String?
//
//    enum CodingKeys: String, CodingKey {
//        case equipmentName = "equipment_name"
//        case equipmentID = "equipment_id"
//        case status
//        case labName = "lab_name"
//        case employeeID = "employee_id"
//        case issuedDate = "issued_date"
//        case solvedDate = "solved_date"
//        case employeeName = "employee_name"
//        
//    }
//}

// MARK: - TechnicianModel
struct Completed: Codable {
    var status: Bool?
    var message: String?
    var data: [CompletedData]?
}

// MARK: - Datum
struct CompletedData: Codable {
    var equipmentName, equipmentID, status, labName: String?
    var employeeID, employeeName, issuedDate, solvedDate: String?
    var serviceID: String?

    enum CodingKeys: String, CodingKey {
        case equipmentName = "equipment_name"
        case equipmentID = "equipment_id"
        case status
        case labName = "lab_name"
        case employeeID = "employee_id"
        case employeeName = "employee_name"
        case issuedDate = "issued_date"
        case solvedDate = "solved_date"
        case serviceID = "service_id"
    }
}

