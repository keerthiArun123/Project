//
//  TechnicianModel.swift
//  Equipment Health
//
//  Created by SAIL on 02/11/23.
//

// This file was generated from JSON Schema using quicktype, do not modify it directly.
// To parse the JSON, add this file to your project and do:
//
//   let welcome = try? JSONDecoder().decode(Welcome.self, from: jsonData)

import Foundation

// MARK: - Welcome
struct Welcome: Codable {
    var data: [Datum]?
}

// MARK: - Datum
struct Datum: Codable {
    var employeeName, employeeID: String?

    enum CodingKeys: String, CodingKey {
        case employeeName = "employee_name"
        case employeeID = "employee_id"
    }
}

