//
//  Postbtn.swift
//  Equipment Health
//
//  Created by SAIL on 01/11/23.
//


import Foundation

// MARK: - Welcome
struct Postbtn: Codable {
    var status, message: String?
}
