//
//  EquipModel.swift
//  Equipment Health
//
//  Created by SAIL on 16/10/23.
//
import Foundation

// MARK: - Welcome
struct Equip: Codable {
    var status, message: String?
}
