//
//  UserNotificationVc.swift
//  Equipment Health
//
//  Created by Haris Madhavan on 27/11/23.
//

import UIKit

class UserNotificationVc: UIViewController {
    
    @IBOutlet weak var notifyTableView: UITableView!
    
    var notificaiton: NotificationModel!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        self.notifyTableView.delegate = self
        self.notifyTableView.dataSource = self
        self.notifyTableView.register(UINib(nibName: "NotificationTableViewCell", bundle: nil), forCellReuseIdentifier: "NotificationTableViewCell")
    }
    
    override func viewWillAppear(_ animated: Bool) {
        GetNotifyAPI()
    }
    
    func GetNotifyAPI() {
        APIHandler().getAPIValues(type: NotificationModel.self, apiUrl: ServiceAPI.NotificationURL, method: "GET") { result in
            switch result {
            case .success(let data):
                self.notificaiton = data
                DispatchQueue.main.async {
                    self.notifyTableView.reloadData()
                }
            case .failure(let error):
                print(error)
                print(error.localizedDescription)
            }
        }
    }

}

extension UserNotificationVc: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.notificaiton?.data?.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "NotificationTableViewCell", for: indexPath) as! NotificationTableViewCell
        
        cell.approveButton.tag = indexPath.row
        cell.approveButton.addTarget(self, action: #selector(approveAction), for: .touchUpInside)
        
        cell.rejectButton.tag = indexPath.row
        cell.rejectButton.addTarget(self, action: #selector(rejectAction), for: .touchUpInside)
        
        if let detail = self.notificaiton?.data?[indexPath.row] {
            cell.equipIdLbl.text = "Equipment Id: \(detail.equipmentID ?? "")"
            cell.equipNameLbl.text = "Equipment Name: \(detail.equipmentName ?? "")"
            cell.empIdLbl.text = "Employee Id: \(detail.employeeID ?? "")"
            cell.empNameLbl.text = "Employee Id: \(detail.employeeName ?? "")"
            cell.issuedDateLbl.text = "Issued Date: \(detail.issuedDate ?? "")"
            cell.solvedDateLbl.text = "Solved Date: \(detail.solvedDate ?? "")"
            cell.descriptionLbl.text = "Description: \(detail.descriptions ?? "")"
            
            if detail.status == "completed" || detail.status == "Not working" {
                cell.isHidden = true
            } else {
                cell.isHidden = false
            }
        }
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 250 + 10
    }
    
    @objc func approveAction(sender: UIButton) {
        let selectedRow = sender.tag
        
        guard let Id = self.notificaiton.data?[selectedRow].equipmentID else {
            return
        }
        guard let status = self.notificaiton.data?[selectedRow].status else {
            return
        }
        
        if let IdIndex = self.notificaiton.data?.firstIndex(where: {$0.equipmentID == Id}),
           let StatusIndex = self.notificaiton.data?.firstIndex(where: {$0.status == status}) {
            if IdIndex == StatusIndex {
                self.notificaiton.data?.remove(at: IdIndex)
                GetNotifyAPI()
            }
            self.notifyTableView.reloadData()
            
            let formData = ["equipment_id": Id, "status": status]
            APIHandler().postAPIValues(type: Postbtn.self, apiUrl: ServiceAPI.acceptURL, method: "POST", formData: formData) { result in
                switch result {
                case .success(let response):
                    print("Status: \(response.status )")
                    print("Message: \(response.message)")
                    DispatchQueue.main.async {
                        self.GetNotifyAPI()
                    }
                case .failure(let error):
                    print("Error: \(error)")
                    // Handle error
                }
            }
        }
        
    }
    
    @objc func rejectAction(sender: UIButton) {
        let selectedRow = sender.tag
        
        guard let Id = self.notificaiton.data?[selectedRow].equipmentID else {
            return
        }
        guard let status = self.notificaiton.data?[selectedRow].status else {
            return
        }
        
        if let IdIndex = self.notificaiton.data?.firstIndex(where: {$0.equipmentID == Id}),
           let StatusIndex = self.notificaiton.data?.firstIndex(where: {$0.status == status}) {
            if IdIndex == StatusIndex {
                self.notificaiton.data?.remove(at: IdIndex)
                GetNotifyAPI()
            }
            self.notifyTableView.reloadData()
            
            let formData = ["equipment_id": Id, "status": status]
            APIHandler().postAPIValues(type: Postbtn.self, apiUrl: ServiceAPI.rejectURL, method: "POST", formData: formData) { result in
                switch result {
                case .success(let response):
                    print("Status: \(response.status )")
                    print("Message: \(response.message)")
                    DispatchQueue.main.async {
                        self.GetNotifyAPI()
                    }
                case .failure(let error):
                    print("Error: \(error)")
                    // Handle error
                }
            }
        }
        
    }
}
