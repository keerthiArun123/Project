//
//  EquipmentDetailVC.swift
//  Equipment Health
//
//  Created by Karthik Babu on 27/09/23.
//

import UIKit

class EquipmentDetailVC: UIViewController {
    
    @IBOutlet weak var id: UILabel!
    @IBOutlet weak var name: UILabel!
    @IBOutlet weak var features: UILabel!
    @IBOutlet weak var purchasedate: UILabel!
    @IBOutlet weak var totservices: UILabel!
    @IBOutlet weak var services: UILabel!
    @IBOutlet weak var price: UILabel!
    @IBOutlet weak var warrantyPeriod: UILabel!
    @IBOutlet weak var warrantyDate: UILabel!
    
    @IBOutlet weak var equipImage: UIImageView!
    var totaldata: Totaldata!
    var dataShowing = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
   
        gettotaldataAPI()
      
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        
    }
    @IBAction func healthCheck(_ sender: Any) {
        let nextVc = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "HealthCheckVC") as! HealthCheckVC
        self.navigationController?.pushViewController(nextVc, animated: true)
        
        
    }
    
  
    func gettotaldataAPI() {
        APIHandler().getAPIValues(type: Totaldata.self, apiUrl: ServiceAPI.totalURL, method: "GET") { result in
            switch result {
            case .success(let totaldata):
                self.totaldata = totaldata
                print(self.totaldata.data ?? "")
                print(self.totaldata.data?.count ?? 0)
                
                DispatchQueue.main.async { [self] in
                    for equipment in self.totaldata.data ?? [] {
                        if equipment.equipmentName == self.dataShowing {
                            self.id.text = "Equipment Id: \(equipment.equipmentID ?? "")"
                            self.name.text = "Equipment Name: \(equipment.equipmentName ?? "")"
                            self.features.text = "Features: \(equipment.features ?? "")"
                            self.purchasedate.text = "Purchase Date: \(equipment.purchaseDate ?? "")"
                            self.totservices.text = "Total Services: \(equipment.totalServices ?? "")"
                            self.services.text = "Services Undergone: \(equipment.servicesUndergone ?? "")"
                            self.price.text = "Price: \(equipment.price ?? "")"
                            self.warrantyDate.text = "Warranty Date: \(equipment.warrantyendDate ?? "")"
                            self.warrantyPeriod.text = "Warranty Period: \(equipment.warrantyPeriod ?? "")"
                            
                            let imgURl = URL(string: "\(equipment.image ?? "")")
                            let data = NSData(contentsOf: imgURl!)
                            self.equipImage.image = .init(data: data! as Data)
                            
                            // You can decide whether to break out of the loop if you've found the desired equipment
                            // break
                        }
                    }

                }
                
            case .failure(let error):
                print(error)
            }
        }
    }

    


//extension EquipmentDetailVC : UITableViewDelegate, UITableViewDataSource {
//
//    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
//        return self.totaldata?.data?.count ?? 1
//    }
//
//    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
//        let cell =  tableView.dequeueReusableCell(withIdentifier: "ProductListTabCell", for: indexPath) as! ProductListTabCell
//
//        if let equipmentDetail = self.totaldata?.data?[indexPath.row] {
//            cell.id.text = "\(equipmentDetail.equipmentID ?? "")"
//            cell.name.text = "\(equipmentDetail.equipmentName ?? "")"
//            cell.features.text = "\(equipmentDetail.equipmentID ?? "")"
//            cell.purchasedate.text = "\(equipmentDetail.equipmentID ?? "")"
//            cell.totservices.text = "\(equipmentDetail.equipmentID ?? "")"
//            cell.services.text = "\(equipmentDetail.equipmentID ?? "")"
//        } else {
//            cell.id.text = "Nil"
//            cell.name.text = "Nil"
//
//        }
//
//        cell.selectedView = {
//
//            let vc = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "EquipmentDetailVC") as! EquipmentDetailVC
//            self.navigationController?.pushViewController(vc, animated: true)
//
//        }
//
//        return cell
//    }
//}
//
}


