//
//  SideMenu.swift
//  Equipment Health
//
//  Created by SAIL on 26/10/23.
//

import Foundation
import UIKit

class MenuListViewController: UITableViewController {
    var items = ["Add", "LogOut"]
    
    let themeColor = UIColor(red: 33/255.0, green: 33/255.0, blue: 33/255.0, alpha: 1)
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.backgroundColor = themeColor
        tableView.register(UITableViewCell.self, forCellReuseIdentifier: "cell")
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
       return items.count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        cell.textLabel?.text = items[indexPath.row]
        cell.textLabel?.textColor = .white
        cell.backgroundColor = themeColor
        
        return cell
    }
    func navigateToViewController(withStoryboardName storyboardName: String, andIdentifier identifier: String) {
        // Load the storyboard
        let storyboard = UIStoryboard(name: storyboardName, bundle: nil)
        
        // Instantiate the view controller from the storyboard
        let viewController = storyboard.instantiateViewController(withIdentifier: identifier)
        
        // Push or present the view controller as needed
        navigationController?.pushViewController(viewController, animated: true)
    }

    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let selectedItem = items[indexPath.row]

        if selectedItem == "Add" {
            // Create an action sheet
            let actionSheet = UIAlertController(title: nil, message: nil, preferredStyle: .actionSheet)

            // Add actions for each option
            let options: [(String, String)] = [
                ("Employee", "AddSupervisorVC"),
                ("Equipment", "AddEquipmentVC"),
                ("Lab", "AddLabVC"),
                ("Building", "AddBuildingVC")
                
            ]

            for (optionTitle, viewControllerIdentifier) in options {
                let action = UIAlertAction(title: optionTitle, style: .default) { (action) in
                    self.navigateToViewController(withStoryboardName: "Main", andIdentifier: viewControllerIdentifier)
                }
                actionSheet.addAction(action)
            }

            // Add a cancel action
            let cancelAction = UIAlertAction(title: "Cancel", style: .cancel, handler: nil)
            actionSheet.addAction(cancelAction)

            // Present the action sheet
            if let popoverController = actionSheet.popoverPresentationController {
                popoverController.sourceView = tableView.cellForRow(at: indexPath)
                popoverController.sourceRect = tableView.cellForRow(at: indexPath)!.bounds
            }

            present(actionSheet, animated: true, completion: nil)
        }
    }

}
