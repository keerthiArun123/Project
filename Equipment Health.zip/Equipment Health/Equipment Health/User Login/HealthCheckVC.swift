//
//  HealthCheckVC.swift
//  Equipment Health
//  Created by SAIL on 30/09/23.
//

import UIKit

class HealthCheckVC: UIViewController {

    @IBOutlet weak var healthtableView: UITableView!
    
    var health: Health!
    var filteredHealth : [HealthData] = []
   var healthKey = ""

    override func viewDidLoad() {
        super.viewDidLoad()
        
        healthtableView.delegate = self
        healthtableView.dataSource = self
        
        let nib = UINib(nibName: "HealthConditionTabCell", bundle: nil)
        healthtableView.register(nib, forCellReuseIdentifier: "HealthConditionTabCell")
    
    }
    
    override func viewWillAppear(_ animated: Bool) {
        getHealthAPI()
        
    }

    @IBAction func nextAc(_ sender: Any) {
        let nextVc = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "DetailsVC") as! DetailsVC

        self.navigationController?.pushViewController(nextVc, animated: true)
        
       
    }
    
    func getHealthAPI() {
        APIHandler().getAPIValues(type: Health.self
                                  , apiUrl: ServiceAPI.healthURL, method: "GET") { result in
            switch result {
            case .success(let data):
                
                self.health = data
                print(self.health.data ?? "")
                print(self.health.data?.count ?? 0)
                DispatchQueue.main.async {
                    self.filteredHealth = self.health.data?.filter { $0.labName == self.healthKey } ?? []
                    self.healthtableView.reloadData()
                }
               

            case .failure(let error):
                print(error)
            }
        }
    }
    
}

extension HealthCheckVC: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.filteredHealth.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell =  tableView.dequeueReusableCell(withIdentifier: "HealthConditionTabCell", for: indexPath) as! HealthConditionTabCell
        
        let healthCheck = self.filteredHealth[indexPath.row] 
            cell.nameLbl.text = "\(healthCheck.equipmentName ?? "")"
            cell.workLbl.text = "\(healthCheck.status ?? "")"
//        } else {
//            cell.nameLbl.text = "Nil"
//            cell.workLbl.text = "Nil"
//        }




        
        return cell
    }
    
    
}
