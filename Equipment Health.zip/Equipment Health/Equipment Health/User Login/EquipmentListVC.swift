//
//  EquipmentListVC.swift
//  Equipment Health
//
//  Created by Karthik Babu on 27/09/23.
//

import UIKit

class EquipmentListVC: UIViewController {
    
    @IBOutlet weak var SearchBar: UISearchBar!
    @IBOutlet weak var totalEquList: UILabel!
    @IBOutlet weak var equipmentTableView: UITableView! {
        didSet{
            equipmentTableView.delegate = self
            equipmentTableView.dataSource = self
        }
    }
    
    var equipments: Equipments!
    var filteredEquipments: [EquipmentData] = []
    var filtered: [EquipmentData]!
    var changekey = ""
    var keyReference = ""
    var searching : Bool = false
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        let nib = UINib(nibName: "ProductListTabCell", bundle: nil)
        equipmentTableView.register(nib, forCellReuseIdentifier: "ProductListTabCell")
        self.SearchBar.delegate = self
        SearchBar.searchTextField.backgroundColor = .white
    }
    
    override func viewWillAppear(_ animated: Bool) {
        getEquipmentAPI()
    }
    
    
    @IBAction func healthCheck(_ sender: Any) {
        let nextVc = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "HealthCheckVC") as! HealthCheckVC
        nextVc.healthKey = keyReference
        self.navigationController?.pushViewController(nextVc, animated: true)
        
        
    }
    
    func getEquipmentAPI() {
        APIHandler().getAPIValues(type: Equipments.self
                                  , apiUrl: ServiceAPI.equipmentURL, method: "GET") { result in
            switch result {
            case .success(let data):
                DispatchQueue.main.async {
                    self.equipments = data
                    print(self.equipments.data?.count ?? 0)
                    self.filteredEquipments = self.equipments.data?.filter { $0.labName == self.keyReference } ?? []
                    self.totalEquList.text = "Total Equipments - \(self.filteredEquipments.count)"
                    self.equipmentTableView.reloadData()
                }
            case .failure(let error):
                print(error)
            }
        }
    }
    
}

extension EquipmentListVC : UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if searching {
            return self.filtered.count
        } else {
            return self.filteredEquipments.count
        }
        //        return self.filteredEquipments.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell =  tableView.dequeueReusableCell(withIdentifier: "ProductListTabCell", for: indexPath) as! ProductListTabCell
        
        
        if searching {
            let equipmentsList = self.filtered[indexPath.row]
            cell.prdName.text = "\(equipmentsList.equipmentName ?? "")"
            let imgURl = URL(string: "\(equipmentsList.image ?? "")")
            let data = NSData(contentsOf: imgURl!)
            cell.imgProduc.image = .init(data: data! as Data)
        } else {
            if keyReference == self.filteredEquipments[indexPath.row].labName {
                let equipmentsList = self.filteredEquipments[indexPath.row]
                cell.prdName.text = "\(equipmentsList.equipmentName ?? "")"
                let imgURl = URL(string: "\(equipmentsList.image ?? "")")
                let data = NSData(contentsOf: imgURl!)
                cell.imgProduc.image = .init(data: data! as Data)
            }
            //            cell.prdLbl.isHidden = true
        }
        
        cell.selectedView = {
            
            let vc = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "EquipmentDetailVC") as! EquipmentDetailVC
            vc.dataShowing = self.filteredEquipments[indexPath.row].equipmentName ?? ""
            self.navigationController?.pushViewController(vc, animated: true)
            
        }
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 130
    }
    
}
extension EquipmentListVC: UISearchBarDelegate {
    
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        
        if searchText.isEmpty {
            searching = false
            filtered.removeAll()
        } else {
            searching = true
            filtered = filteredEquipments.filter{$0.equipmentName?.range(of: searchText, options: .caseInsensitive) != nil}
        }
        equipmentTableView.reloadData()
    }
    
    func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
        searchBar.text = ""
    }
}
