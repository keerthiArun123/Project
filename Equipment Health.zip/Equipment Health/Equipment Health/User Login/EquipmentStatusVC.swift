//
//  EquipmentStatusVC.swift
//  Equipment Health
//
//  Created by SAIL on 29/09/23.
//

import UIKit

class EquipmentStatusVC: UIViewController {

    var statuss:Statuss!
    @IBOutlet weak var cancelView: UIView!
    @IBOutlet weak var reportView: UIView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        cancelView.layer.cornerRadius = 10
        
        reportView.addAction(for: .tap) {
             
            
        }
       
    }
    override func viewWillAppear(_ animated: Bool) {
        getStatussAPI()
    }
    
    @IBAction func info(_ sender: Any) {
        let nextVc = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "TutorialsVC") as! TutorialsVC
        
        self.navigationController?.pushViewController(nextVc, animated: true)
    }
    
    func getStatussAPI() {
        APIHandler().getAPIValues(type: Statuss.self
                                  , apiUrl: ServiceAPI.statussURL, method: "GET") { result in
            switch result {
            case .success(let data):
                self.statuss = data
                print(self.statuss.data ?? "")
                print(self.statuss.data?.count ?? 0)
               
            case .failure(let error):
                print(error)
            }
        }
    }
    
}
