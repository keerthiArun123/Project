//
//  DetailsVC.swift
//  Equipment Health
//
//  Created by SAIL on 29/09/23.
//

import UIKit

class DetailsVC: UIViewController, UIImagePickerControllerDelegate & UINavigationControllerDelegate {
    
    var problemdetails: ReportModel!
    
    var report: GetReportModel!
    var reportData: [GetReport]!
    
    @IBOutlet weak var name: UITextField!
    @IBOutlet weak var idLbl: UITextField!
    @IBOutlet weak var labLbel: UITextField!
    
    @IBOutlet weak var dateLbl: UITextField!
    @IBOutlet weak var probdesc: UITextField!
    
    let datePicker : UIDatePicker = UIDatePicker()
    
    var dataShowing = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //        addBtn.layer.cornerRadius = 10
        
        self.name.delegate = self
        self.idLbl.delegate = self
        self.labLbel.delegate = self
        self.dateLbl.delegate = self
        self.dateLbl.tag = 0
    }
    
    func report(_ sender: Any) {
        let nextVc = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "EquipmentStatusVC") as! EquipmentStatusVC
        
        self.navigationController?.pushViewController(nextVc, animated: true)
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        GetAPI()
    }
    
    @IBAction func reportAction(_ sender: Any) {
                self.ProblemdetailsAPI()
    }
    
    func GetAPI() {
        APIHandler().getAPIValues(type: GetReportModel.self, apiUrl: ServiceAPI.reportDetails, method: "GET") { result in
            switch result {
            case .success(let data):
                self.report = data
                self.reportData = self.report.data
            case .failure(let error):
                print(error)
                print(error.localizedDescription)
            }
        }
    }
    
    func ProblemdetailsAPI() {
        let formData: [String: String] = [
            "equipment_id": idLbl.text ?? "",
            "problem_specification": probdesc.text ?? "",
            "equipment_name": name.text ?? "",
            "issued_date": dateLbl.text ?? "",
            "lab_name": labLbel.text ?? ""
        ]
        APIHandler().postAPIValues(type: ReportModel.self,apiUrl: ServiceAPI.ProblemdetailsURL, method: "POST", formData: formData) { result in
            switch result {
            case .success(let response):
                print("Status: \(response.status ?? "")")
                print("Message: \(response.message ?? "")")
                DispatchQueue.main.async {
                    AlertManager.showAutoDismissAlert(title: "\(response.status ?? "")", message: "\(response.message ?? "")", viewController: self, navigationController: self.navigationController!, duration: 2.0)
                }
            case .failure(let error):
                print("Error: \(error)")
                print(error.localizedDescription)
            }
        }
    }
    
}

extension DetailsVC: UITextFieldDelegate {
    
    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool {
        
        if textField == name {
            print("TextFieldShouldBeginEditing called for \(textField)")
            let equipmentIDs = self.reportData.compactMap { $0.equipmentName }
            AlertManager.showAction(title: "Select Equipment", message: "", options: equipmentIDs, viewController: self) { selectedID in
                
                print(selectedID)
                
                textField.text = selectedID
            }
            return false
        } else if textField == idLbl{
            print("TextFieldShouldBeginEditing called for \(textField)")
            let equipmentIDs = self.reportData.compactMap { $0.equipmentID }
            AlertManager.showAction(title: "Select Equipment ID", message: "", options: equipmentIDs, viewController: self) { selectedID in
                
                print(selectedID)
                
                textField.text = selectedID
            }
            return false
        } else if textField == labLbel {
            print("TextFieldShouldBeginEditing called for \(textField)")
            let equipmentIDs = self.reportData.compactMap { $0.labName }
            AlertManager.showAction(title: "Select Lab", message: "", options: equipmentIDs, viewController: self) { selectedID in
                
                print(selectedID)
                
                textField.text = selectedID
            }
            return false
        } else if textField == dateLbl {
            textField.addTarget(self, action: #selector(dateTextFieldBeginEditing), for: .editingDidBegin)
        }
        return true
    }
    
    @objc func dateTextFieldBeginEditing(_ sender: UITextField) {
        showDatePicker(tag: sender.tag)
    }
    
    func showDatePicker(tag: Int){
        datePicker.datePickerMode = .date
        
        if #available(iOS 13.4, *) {
            datePicker.preferredDatePickerStyle = .wheels
        }
        else {
            datePicker.preferredDatePickerStyle = .wheels
        }
        let toolbar = UIToolbar();
        toolbar.sizeToFit()
        let doneButton = UIBarButtonItem(title: "Done", style: UIBarButtonItem.Style.done, target: self, action: #selector(self.donedatePicker(_ :)))
        doneButton.tag = tag
        let spaceButton = UIBarButtonItem(barButtonSystemItem: UIBarButtonItem.SystemItem.flexibleSpace, target: nil, action: nil)
        
        let cancelButton = UIBarButtonItem(title: "Cancel", style: UIBarButtonItem.Style.plain, target: self, action: #selector(self.cancelDatePicker(_ :)))
        cancelButton.tag = tag
        toolbar.setItems([cancelButton ,spaceButton,doneButton], animated: false)
        self.dateLbl.inputAccessoryView = toolbar
        self.dateLbl.inputView = datePicker
    }
    
    @objc func cancelDatePicker(_ sender: UIButton){
        self.dateLbl.text? = ""
        self.view.endEditing(true)
    }
    
    @objc func donedatePicker(_ sender: UIButton){
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy-MM-dd"
        self.dateLbl.text = formatter.string(from: datePicker.date)
        self.view.endEditing(true)
    }
}
