//
//  HomeViewController.swift
//  Equipment Health
//
//  Created by Karthik Babu on 27/09/23.
//

import UIKit

class HomeViewController: UIViewController{
    
    
    @IBOutlet weak var tableView: UITableView!
    
    var building: Building!
    
    var areaArray = ["Saveetha School of Engineering", "SAIL", "SCAD", "Saveetha Medical College", "AHS", "Saveetha Nursing College"]
    
    @IBOutlet weak var notifications: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.tableView.delegate = self
        self.tableView.dataSource = self
        
        self.notifications.addAction(for: .tap) {
            let vc = self.storyboard?.instantiateViewController(withIdentifier: "UserNotificationVc") as! UserNotificationVc
            self.navigationController?.pushViewController(vc, animated: true)
        }
    
    }
    override func viewWillAppear(_ animated: Bool) {
        getBuildingAPI()
    }
 
    func getBuildingAPI() {
        APIHandler().getAPIValues(type: Building.self
                                  , apiUrl: ServiceAPI.buildingURL, method: "GET") { result in
            switch result {
            case .success(let data):
                self.building = data
                print(self.building.data ?? "")
                print(self.building.data?.count ?? 0)
                DispatchQueue.main.async {
                    self.tableView.reloadData()
                }
            case .failure(let error):
                print(error)
            }
        }
    }
}

extension HomeViewController : UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.building?.data?.count ?? 1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell =  tableView.dequeueReusableCell(withIdentifier: "ChooseClgTabCell", for: indexPath) as! ChooseClgTabCell
       
        if let building = self.building?.data?[indexPath.row] {
            
            cell.titleLbl.text = "\(building.buildingName ?? "")"
        } else {
            
            cell.titleLbl.text = "Nil"
        }
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 85
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        LabListVc()
        let nextVC = UIStoryboard(name: "Main" , bundle: nil).instantiateViewController(withIdentifier: "LabListVc") as! LabListVc
        self.navigationController?.pushViewController(nextVC, animated: true)
    }
}
