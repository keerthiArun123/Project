//
//  SignUpViewController.swift
//  Equipment Health
//
//  Created by Karthik Babu on 27/09/23.
//

import UIKit

class SignUpViewController: UIViewController {

    @IBOutlet weak var IdTextField: UITextField!
    
    @IBOutlet weak var NameTextField: UITextField!
    
    @IBOutlet weak var PasswordTextField: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func signUpAction(_ sender: Any) {
            SignAPI()
        }
    

    @IBAction func loginAction(_ sender: Any) {
        SignAPI()
//        let vc = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "HomeViewController") as! HomeViewController
//        self.navigationController?.pushViewController(vc, animated: true)
    }
    func SignAPI() {
            let formData: [String: String] = [
                "email": IdTextField.text ?? "",
                "employee_name": NameTextField.text ?? "",
                "password": PasswordTextField.text ?? "",
                
            ]
            APIHandler().postAPIValues(type: Sign.self, apiUrl: ServiceAPI.signUp, method: "POST", formData: formData) { result in
                switch result {
                case .success(let response):
                    print("Status: \(response.status)")
                    print("Message: \(response.message ?? "")")
                    DispatchQueue.main.async {
                       print(formData)
                        AlertManager.showAutoDismissAlert(title: "Success", message: "\(response.message ?? "")", viewController: self, navigationController: self.navigationController!, duration: 2.0)
                    }
                case .failure(let error):
                    print("Error: \(error)")
                }
            }
        }
        /*
        // MARK: - Navigation

        // In a storyboard-based application, you will often want to do a little preparation before navigation
        override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
            // Get the new view controller using segue.destination.
            // Pass the selected object to the new view controller.
        }
        */

    }

