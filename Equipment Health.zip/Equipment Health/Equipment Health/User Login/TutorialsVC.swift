//
//  TutorialsVC.swift
//  Equipment Health
//
//  Created by SAIL on 29/09/23.
//

import UIKit

class TutorialsVC: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func home(_ sender: Any) {
        let nextVc = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "HomeViewController") as! HomeViewController
        
        self.navigationController?.pushViewController(nextVc, animated: true)
    }
    
}
