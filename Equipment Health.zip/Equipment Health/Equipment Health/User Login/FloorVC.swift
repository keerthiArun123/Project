//
//  FloorVC.swift
//  Equipment Health
//
//  Created by Karthik Babu on 27/09/23.
//

import UIKit

class FloorVC: UIViewController {
        
        @IBOutlet weak var tableView: UITableView!
    
    
    var floor: Floor!
    var keyReference = ""
    var areaArray = ["Floor 1", "Floor 2", "Floor 3", "Floor 4", "Floor 5", "Floor 6", "Floor 7", "Floor 8", "Floor 9", "Floor 10"]
        

        override func viewDidLoad() {
            super.viewDidLoad()
            
            self.tableView.delegate = self
            self.tableView.dataSource = self

            
        }
    override func viewWillAppear(_ animated: Bool) {
        getFloorAPI()
    }
 
    func getFloorAPI() {
        APIHandler().getAPIValues(type: Floor.self
                                  , apiUrl: ServiceAPI.floorURL, method: "GET") { result in
            switch result {
            case .success(let data):
                self.floor = data
                print(self.floor.data ?? "")
                print(self.floor.data?.count ?? 0)
                DispatchQueue.main.async {
                    self.tableView.reloadData()
                }
            case .failure(let error):
                print(error)
            }
        }
        
    }
        


    
    }


/*extension FloorVC : UITableViewDelegate, UITableViewDataSource {
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return areaArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "FloorTabCell", for: indexPath) as! FloorTabCell
        //cell.titleLbl.text = areaArray[indexPath.row]
        cell.floorLbl.text = areaArray[indexPath.row]
        cell.view.layer.cornerRadius = 10
        

        
        cell.dropDown.addAction(for: .tap) {
        let actionSheetAlertController: UIAlertController = UIAlertController(title: nil, message: "Select", preferredStyle: .actionSheet)
        let i = 5
        if i != 0 {
            for  n in 0...i {
                let action = UIAlertAction(title: "Ratings", style: .default) { (action) in
                }
                action.setValue(CATextLayerAlignmentMode.left, forKey: "titleTextAlignment")
                action.setValue(UIColor.black, forKey: "titleTextColor")
                actionSheetAlertController.addAction(action)
            }
        }
        let cancelActionButton = UIAlertAction(title: "Cancel", style: .destructive, handler: nil)
        actionSheetAlertController.addAction(cancelActionButton)
        self.present(actionSheetAlertController, animated: true, completion: nil)
        }
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 50
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let vc = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "EquipmentListVC") as! EquipmentListVC
        self.navigationController?.pushViewController(vc, animated: true)
    }
}*/

extension FloorVC : UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.floor?.data?.count ?? 1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell =  tableView.dequeueReusableCell(withIdentifier: "FloorTabCell", for: indexPath) as! FloorTabCell
       
        if let floor = self.floor?.data?[indexPath.row] {
            
            cell.floorLbl.text = "\(floor.floor ?? "")"
        } else {
            
            cell.floorLbl.text = "Nil"
        }
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 85
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "EquipmentListVC") as! EquipmentListVC
        vc.changekey = keyReference
        self.navigationController?.pushViewController(vc, animated: true)
    }
}

