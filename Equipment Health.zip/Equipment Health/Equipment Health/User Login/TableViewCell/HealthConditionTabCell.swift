//
//  HealthConditionTabCell.swift
//  Equipment Health
//
//  Created by SAIL on 30/09/23.
//

import UIKit

class HealthConditionTabCell: UITableViewCell {

    @IBOutlet weak var modelNoLbl: UILabel!
    @IBOutlet weak var img: UIImageView!
    @IBOutlet weak var workLbl: UILabel!
    @IBOutlet weak var nameLbl: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
