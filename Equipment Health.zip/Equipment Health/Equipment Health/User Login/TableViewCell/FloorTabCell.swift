//
//  FloorTabCell.swift
//  Equipment Health
//
//  Created by SAIL on 30/09/23.
//

import UIKit

class FloorTabCell: UITableViewCell {

    @IBOutlet weak var view: UIView!
    @IBOutlet weak var dropDown: UIImageView!
    @IBOutlet weak var floorLbl: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
