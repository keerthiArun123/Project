//
//  NotificationTableViewCell.swift
//  Equipment Health
//
//  Created by Haris Madhavan on 27/11/23.
//

import UIKit

class NotificationTableViewCell: UITableViewCell {
    
    @IBOutlet weak var equipNameLbl: UILabel!
    @IBOutlet weak var equipIdLbl: UILabel!
    @IBOutlet weak var empNameLbl: UILabel!
    @IBOutlet weak var empIdLbl: UILabel!
    @IBOutlet weak var issuedDateLbl: UILabel!
    @IBOutlet weak var solvedDateLbl: UILabel!
    @IBOutlet weak var approveButton: UIButton!
    @IBOutlet weak var rejectButton: UIButton!
    @IBOutlet weak var descriptionLbl: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
