//
//  LabListVc.swift
//  Equipment Health
//
//  Created by Karthik Babu on 27/09/23.
//

import UIKit

class LabListVc: UIViewController, UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    
    @IBOutlet weak var labCollectionView: UICollectionView!
    @IBOutlet weak var SearchBar: UISearchBar!
    
    var labget: LabgetModel!
    var filtered : [labgetdata]!
    var searching : Bool = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.labCollectionView.delegate = self
        self.labCollectionView.dataSource = self
        
        self.SearchBar.delegate = self
        SearchBar.searchTextField.backgroundColor = .white
        
        let numbersOfColumns: CGFloat = 2
        let columnSpacing: CGFloat = (numbersOfColumns - 1) * 10
        let width = (self.view.frame.size.width - columnSpacing) / numbersOfColumns
        let layout = labCollectionView.collectionViewLayout as! UICollectionViewFlowLayout
        layout.itemSize = CGSize(width: width, height: width)
        
        let direction = UICollectionViewFlowLayout()
        direction.scrollDirection = .vertical
        direction.itemSize = CGSize(width: self.labCollectionView.frame.size.width / 2.1, height: 150.0)
        self.labCollectionView.collectionViewLayout = direction
    
    }
    
    override func viewWillAppear(_ animated: Bool) {
        labgetAPI()
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        if searching {
            return filtered.count
        } else {
        return labget?.data?.count ?? 0
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "LabCollectionViewCell", for: indexPath) as! LabCollectionViewCell
        
        cell.contentView.layer.cornerRadius = 10
        
        if searching {
            cell.labNameLabel.text = filtered[indexPath.row].labName
        } else {
        cell.labNameLabel.text = labget?.data?[indexPath.row].labName
        }
        
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {
        return UIEdgeInsets(top: 0, left: 10, bottom: 0, right: 10)
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let vc = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "EquipmentListVC") as! EquipmentListVC
        vc.keyReference = labget?.data?[indexPath.row].labName ?? ""
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    func labgetAPI() {
        APIHandler().getAPIValues(type: LabgetModel.self
                                  , apiUrl: ServiceAPI.LabgetURL, method: "GET") { result in
            switch result {
            case .success(let data):
                self.labget = data
                print(self.labget.data ?? "")
                print(self.labget.data?.count ?? 0)
                DispatchQueue.main.async {
                    self.labCollectionView.reloadData()
                }
            case .failure(let error):
                print(error)
            }
        }
    }
}

extension LabListVc: UISearchBarDelegate {
    
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        
        if searchText.isEmpty {
            searching = false
            filtered.removeAll()
        } else {
            searching = true
            filtered = labget.data?.filter{$0.labName?.range(of: searchText, options: .caseInsensitive) != nil}
        }
        labCollectionView.reloadData()
    }
    
    func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
        searchBar.text = ""
    }
}

