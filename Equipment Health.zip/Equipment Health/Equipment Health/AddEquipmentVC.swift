//
//  AddEquipmentVC.swift
//  Equipment Health
//
//  Created by Karthik Babu on 29/09/23.
//

import UIKit

class AddEquipmentVC: UIViewController {
    
    @IBOutlet weak var nameTextField: UITextField!
    @IBOutlet weak var idTextField: UITextField!
    
    @IBOutlet weak var statusTextField: UITextField!
    
    @IBOutlet weak var featuresTextField: UITextField!
    
    @IBOutlet weak var serviceTextField: UITextField!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    @IBAction func addAction(_ sender: Any) {
        self.EquipAPI()
    }
    func EquipAPI() {
            let formData: [String: String] = [
                "equipment_name": nameTextField.text ?? "",
                "equipment_id": idTextField.text ?? "",
                "status": statusTextField.text ?? "",
                "features": featuresTextField.text ?? "",
                "services_undergone": serviceTextField.text ?? "",
                /*"Designation": designationTextField.text ?? "",
                "contact_no": numberTextField.text ?? "",
                "Address": AddressTextField.text ?? "",
                "blood_group": bloodgroupTextField.text ?? ""*/
                
            ]
            APIHandler().postAPIValues(type: Equip.self,apiUrl: ServiceAPI.equipURL, method: "POST", formData: formData) { result in
                switch result {
                case .success(let response):
                    print("Status: \(response.status ?? "")")
                    print("Message: \(response.message ?? "")")
                    DispatchQueue.main.async {
                       print(formData)
                    }
                case .failure(let error):
                    print("Error: \(error)")
                }
            }
        }
}
