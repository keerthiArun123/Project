//
//  StatementVC.swift
//  Equipment Health
//
//  Created by SAIL on 03/10/23.
//

import UIKit

class StatementVC: UIViewController {
    
    var allocated: Allocated!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    @IBAction func submit(_ sender: Any) {
        let nextVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "JobSuccessVC") as! JobSuccessVC
         self.navigationController?.pushViewController(nextVC, animated: true)
        
    }

    

}
