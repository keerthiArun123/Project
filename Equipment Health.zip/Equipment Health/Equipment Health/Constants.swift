//
//  Constants.swift
//  Equipment Health
//
//  Created by Karthik Babu on 27/09/23.
//

import Foundation
import UIKit


class NavigationHelper {
    
    
    static var shared: NavigationHelper = NavigationHelper()
    
    
    init() {}
    
    func pushViewControl(storyBoard: String, StoryBoardId: String, navigationController: UINavigationController) {
        let vc = UIStoryboard(name: storyBoard, bundle: nil).instantiateViewController(withIdentifier: StoryBoardId)
        navigationController.pushViewController(vc, animated: true)
    }
    
}
