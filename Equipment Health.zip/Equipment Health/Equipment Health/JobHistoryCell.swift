//
//  JobHistoryCell.swift
//  Equipment Health
//
//  Created by SAIL on 29/09/23.
//

import UIKit

class JobHistoryCell: UITableViewCell {
    
    
    @IBOutlet weak var equipmentNameLbl: UILabel!
    @IBOutlet weak var idNoLbl: UILabel!
    @IBOutlet weak var kitStatusLbl: UILabel!
    @IBOutlet weak var labLocationlbl: UILabel!
    @IBOutlet weak var dateLbl: UILabel!
    @IBOutlet weak var dropDown: UIButton!
    @IBOutlet weak var tech: UILabel!
    @IBOutlet weak var jobId: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        
        
        
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
