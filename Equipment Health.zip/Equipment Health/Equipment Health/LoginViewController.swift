//
//  LoginViewController.swift
//  Equipment Health
//
//  Created by Karthik Babu on 27/09/23.
//

import UIKit

class LoginViewController: UIViewController {

    @IBOutlet weak var signUp: UIButton!
    @IBOutlet weak var userIdTF: UITextField!
    @IBOutlet weak var PasswordTF: UITextField!
    
    var apiURL = String()
    var login: LoginModel!
    
    override func viewDidLoad() {
        super.viewDidLoad()

//        self.navigationItem.leftBarButtonItem = UIBarButtonItem(image: UIImage(systemName: ""), style: .plain, target: self, action: nil)
        
        self.PasswordTF.isSecureTextEntry = true
        
        signUp.addAction(for: .tap) {
            let vc = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "SignUpViewController") as! SignUpViewController
            self.navigationController?.pushViewController(vc, animated: true)
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        userIdTF.text = ""
        userIdTF.becomeFirstResponder()
        
        PasswordTF.text = ""
        PasswordTF.resignFirstResponder()
    }

    @IBAction func loginAction(_ sender: Any) {
        
        if userIdTF.text == "" && PasswordTF.text == "" {
            let alert = UIAlertController(title: "Alert", message: "Textfield is Empty", preferredStyle: UIAlertController.Style.alert)
            alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
            present(alert, animated: true)
        } else {
            getLoginAPI()
        }
    }
    
    func getLoginAPI() {
        APIHandler().getAPIValues(type: LoginModel.self, apiUrl: "\(ServiceAPI.loginURL)username=\(userIdTF.text  ?? "")&password=\(PasswordTF.text ?? "")", method: "GET") { result in
            switch result{
            case .success(let data):
                self.login = data
                print(self.login.data ?? "")
                DispatchQueue.main.async {
                    if self.userIdTF.text != self.login.data?.userID && self.PasswordTF.text != self.login.data?.password {
                        let alert = UIAlertController(title: "Alert", message: "Incorrect Credentials", preferredStyle: UIAlertController.Style.alert)
                        alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
                        self.present(alert, animated: true)
                    } else {
                        if self.login.data?.did == "1"{
                            UserDefaultsManager.shared.saveUserId(self.userIdTF.text ?? "")
                            let vc = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "ChooseSupervisorVC") as! ChooseSupervisorVC
                            self.navigationController?.pushViewController(vc, animated: true)
                        } else if self.login.data?.did == "2"{
                            UserDefaultsManager.shared.saveUserId(self.userIdTF.text ?? "")
                            let vc = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "JobHistoryVC") as! JobHistoryVC
                            self.navigationController?.pushViewController(vc, animated: true)
                        } else if self.login.data?.did == "3"{
                            UserDefaultsManager.shared.saveUserId(self.userIdTF.text ?? "")
                            let vc = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "WorkAllocatedVC") as! WorkAllocatedVC
                            self.navigationController?.pushViewController(vc, animated: true)
                        } else if self.login.data?.did == "4"{
                            UserDefaultsManager.shared.saveUserId(self.userIdTF.text ?? "")
                            let vc = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "HomeViewController") as! HomeViewController
                            self.navigationController?.pushViewController(vc, animated: true)
                        }
                    }
                }
            case .failure(let error):
                print(error)
            }
        }
    }
}
