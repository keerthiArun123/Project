//
//  WorkAllocatedVC.swift
//  Equipment Health
//
//  Created by SAIL on 03/10/23.
//

import UIKit

class WorkAllocatedVC: UIViewController{
    
    @IBOutlet weak var workTableView: UITableView! {
        didSet {
            workTableView.delegate = self
            workTableView.dataSource = self
        }
    }
    
    var allocated: Allocated!
    
    override func viewDidLoad() {
        super.viewDidLoad()
            
           
        }
    
    override func viewWillAppear(_ animated: Bool) {
        getAllocatedAPI()
    }

    @IBAction func nextAction(_ sender: Any) {
       
                let nextVc = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "StatementViewController") as! StatementViewController
                self.navigationController?.pushViewController(nextVc, animated: true)
            
    }
    
    
func WORK(_ sender: Any) {
        let nextVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "StatementViewController") as! StatementViewController
         self.navigationController?.pushViewController(nextVC, animated: true)
    }
    func getAllocatedAPI() {
        
        let userId = UserDefaultsManager.shared.getUserName() ?? ""
        
        APIHandler().getAPIValues(type: Allocated.self
                                  , apiUrl: "\(ServiceAPI.allocatedURL)employee_name=\(userId)", method: "GET") { result in
            switch result {
            case .success(let data):
                self.allocated = data
                print(self.allocated.data ?? "")
                print(self.allocated.data?.count ?? 0)
                DispatchQueue.main.async {
                    self.workTableView.reloadData()
                }
            case .failure(let error):
                print(error)
            }
        }
    }
    
}
extension WorkAllocatedVC : UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.allocated?.data?.count ?? 1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell =  tableView.dequeueReusableCell(withIdentifier: "WorkAllocatedCell", for: indexPath) as! WorkAllocatedCell
       
        if let allocated = self.allocated?.data?[indexPath.row] {
            
            cell.equpName.text = "\(allocated.equipmentName ?? "")"
            cell.equpId.text = "\(allocated.equipmentID ?? "")"
            cell.status.text = "\(allocated.status ?? "")"
            cell.labName.text = "\(allocated.labName ?? "")"
            cell.date.text = "\(allocated.issuedDate ?? "")"
        } else {
            
            cell.equpName.text = ""
            cell.equpId.text = ""
            cell.status.text = ""
            cell.labName.text = ""
            cell.date.text = ""
        }
        
        return cell
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 150
    }
}


    
    



