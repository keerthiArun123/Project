//
//  AddBuildingVC.swift
//  Equipment Health
//
//  Created by Karthik Babu on 29/09/23.
//

import UIKit

class AddBuildingVC: UIViewController {
    
    
    @IBOutlet weak var buildingName: UITextField!
    
    @IBOutlet weak var buildingId: UITextField!
    
    @IBOutlet weak var noOfRooms: UITextField!
    
    @IBOutlet weak var totalRooms: UITextField!
    
    @IBOutlet weak var totalLabs: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    

    @IBAction func addAction(_ sender: Any) {
        self.AddbuildAPI()
    }
    func AddbuildAPI() {
            let formData: [String: String] = [
                "Building_name": buildingName.text ?? "",
                "Building_id": buildingId.text ?? "",
                "total_floor": noOfRooms.text ?? "",
                "total_rooms": totalRooms.text ?? "",
                "total_lab": totalLabs.text ?? "",
                /*"Designation": designationTextField.text ?? "",
                "contact_no": numberTextField.text ?? "",
                "Address": AddressTextField.text ?? "",
                "blood_group": bloodgroupTextField.text ?? ""*/
                
            ]
        APIHandler().postAPIValues(type: Addbuild.self, apiUrl: ServiceAPI.AddbuildURL, method: "POST", formData: formData) { result in
                switch result {
                case .success(let response):
                    print("Status: \(response.status ?? "")")
                    print("Message: \(response.message ?? "")")
                    DispatchQueue.main.async {
                       print(formData)
                    }
                case .failure(let error):
                    print("Error: \(error)")
                }
            }
        }

}
