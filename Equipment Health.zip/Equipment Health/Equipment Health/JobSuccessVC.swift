//
//  JobSuccessVC.swift
//  Equipment Health
//
//  Created by Karthik Babu on 29/09/23.
//

import UIKit

class JobSuccessVC: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        DispatchQueue.main.async {
            let nextVc = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "SelectUserVC") as! SelectUserVC
            self.navigationController?.pushViewController(nextVc, animated: true)
        }
 
    }
    

}
