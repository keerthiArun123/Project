//
//  WorkAllocatedCell.swift
//  Equipment Health
//
//  Created by SAIL on 26/10/23.
//

import UIKit

class WorkAllocatedCell: UITableViewCell {
    @IBOutlet weak var dropDown: UIButton!
    @IBOutlet weak var date: UILabel!
    @IBOutlet weak var labName: UILabel!
    @IBOutlet weak var status: UILabel!
    @IBOutlet weak var equpId: UILabel!
    @IBOutlet weak var equpName: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
