//
//  ChooseSupervisorVC.swift
//  Equipment Health
//
//  Created by Karthik Babu on 29/09/23.
//

import UIKit
import SideMenu

class ChooseSupervisorVC: UIViewController {
    
    @IBOutlet weak var sideMenu: UIImageView!
    @IBOutlet weak var tableView: UITableView!
    
    var selectedIndexPaths: [IndexPath] = []
    var empName = String()
    var supervisor: Supervisor!
    var building: Building!
    var menu: SideMenuNavigationController?
    var clgName = String()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.delegate = self
        tableView.dataSource = self
        let nib = UINib(nibName: "SelectSupervisorTabCell", bundle: nil)
        tableView.register(nib, forCellReuseIdentifier: "SelectSupervisorTabCell")
        menu = SideMenuNavigationController(rootViewController: MenuListViewController())
        menu?.leftSide = false
        menu?.presentationStyle = .menuSlideIn
        
        // Set the side menu properties
        SideMenuManager.default.rightMenuNavigationController = menu
        SideMenuManager.default.addPanGestureToPresent(toView: self.view)
        sideMenu.addAction(for: .tap, Action: {
            self.present(self.menu!, animated: true, completion: nil)
        })
    }
    
    override func viewWillAppear(_ animated: Bool) {
        getSupervisorAPI()
        
    }
    func PostbtnAPI() {
        
        if let cell = tableView.dequeueReusableCell(withIdentifier: "SelectSupervisorTabCell") as? SelectSupervisorTabCell {
            
            let formData: [String: String] = [
                "employee_name": cell.name_Lbl.text ?? "",
                "college_name": self.clgName
            ]
            APIHandler().postAPIValues(type: Postbtn.self, apiUrl: ServiceAPI.PostbtnURL, method: "POST", formData: formData) { result in
                switch result {
                case .success(let response):
                    print("Status: \(response.status ?? "")")
                    print("Message: \(response.message ?? "")")
                    DispatchQueue.main.async {
                        print(formData)
                    }
                case .failure(let error):
                    print("Error: \(error)")
                }
            }
        }
    }
    
    func getSupervisorAPI() {
        APIHandler().getAPIValues(type: Supervisor.self
                                  , apiUrl: ServiceAPI.supervisorURL, method: "GET") { result in
            switch result {
            case .success(let data):
                self.supervisor = data
                print(self.supervisor.data ?? "")
                print(self.supervisor.data?.count ?? 0)
                DispatchQueue.main.async {
                    self.tableView.reloadData()
                }
            case .failure(let error):
                print(error)
            }
        }
    }
    
    func GetBuildingList() {
        APIHandler().getAPIValues(type: Building.self
                                  , apiUrl: ServiceAPI.buildingURL, method: "GET") { result in
            switch result {
            case .success(let data):
                self.building = data
                print(self.building.data ?? "")
                print(self.building.data?.count ?? 0)
                self.GetBuildingListAPI()
                DispatchQueue.main.async {
                    self.tableView.reloadData()
                }
            case .failure(let error):
                print(error)
            }
        }
        
    }
    
    func GetBuildingListAPI() {
        guard let buildingData = building.data else {
            print("No building data available")
            return
        }
        
        let actionSheetAlertController: UIAlertController = UIAlertController(title: nil, message: "Select", preferredStyle: .actionSheet)
        
        for (_, buildingInfo) in buildingData.enumerated() {
            let action = UIAlertAction(title: buildingInfo.buildingName, style: .default) { (action) in
                DispatchQueue.main.async {
                    print("Title: \(String(describing: buildingInfo.buildingName))")
                    //                    print("Building ID : \(String(/*describing*/: buildingInfo.)  )")
                    // Handle the selection here
                    self.clgName = buildingInfo.buildingName ?? ""
                    self.PostbtnAPI()
                }
            }
            action.setValue(CATextLayerAlignmentMode.left, forKey: "titleTextAlignment")
            action.setValue(UIColor.black, forKey: "titleTextColor")
            actionSheetAlertController.addAction(action)
        }
        
        let cancelActionButton = UIAlertAction(title: "Cancel", style: .destructive, handler: nil)
        actionSheetAlertController.addAction(cancelActionButton)
        
        DispatchQueue.main.async {
            self.present(actionSheetAlertController, animated: true, completion: nil)
        }
    }
    
    
    
    
}
extension ChooseSupervisorVC : UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.supervisor?.data?.count ?? 1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "SelectSupervisorTabCell", for: indexPath) as! SelectSupervisorTabCell
        
//        cell.clg_Lbl.isHidden = true
        
        if selectedIndexPaths.contains(indexPath) {
            // Set the radioOn image for the selected state.
            cell.radioBtn.setImage(UIImage(named: "radioon"), for: .selected)
            empName = self.supervisor?.data?[indexPath.row].buildingName ?? "Nil"
            print(empName,"--->")
        } else {
            // Set the radioOff image for the normal state.
            cell.radioBtn.setImage(UIImage(named: "radiooff"), for: .normal)
        }
        cell.dropDown.addAction(for: .tap) {
            self.GetBuildingList()
        }
        
        cell.radioBtn.isSelected = selectedIndexPaths.contains(indexPath)
        
        cell.radioBtn.addTarget(self, action: #selector(radioButtonTapped(_:)), for: .touchUpInside)
        
        cell.name_Lbl.text = self.supervisor?.data?[indexPath.row].employeeName ?? "No Data"
        cell.clg_Lbl.text = self.supervisor?.data?[indexPath.row].buildingName ?? ""
        
        
        
        return cell
    }
    
    @objc func radioButtonTapped(_ sender: UIButton) {
        if let cell = sender.superview as? SelectSupervisorTabCell, let indexPath = tableView.indexPath(for: cell) {
            if selectedIndexPaths.contains(indexPath) {
                selectedIndexPaths.removeAll { $0 == indexPath }
            } else {
                selectedIndexPaths.append(indexPath)
            }
            tableView.reloadData() // Reload the table view to update the cell appearance.
        }
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        // When a cell is selected, toggle its selection state and update the UI.
        if selectedIndexPaths.contains(indexPath) {
            selectedIndexPaths.removeAll { $0 == indexPath }
        } else {
            selectedIndexPaths.append(indexPath)
        }
        
        tableView.reloadData() // Reload the table view to update the cell appearance.
    }
    
    
}
