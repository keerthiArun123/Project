//
//  SelectAreaVC.swift
//  Equipment Health
//
//  Created by SAIL on 29/09/23.
//

import UIKit

class SelectAreaVC: UIViewController {

    
    @IBOutlet weak var selectTable: UITableView!
    
    var college: College!
    
    var collegeListArray = ["Saveetha School of Engineering", "SAIL", "SCAD", "Saveetha Mdeical College", "AHS", "Saveetha Nursing College"]

    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        selectTable.dataSource = self
        selectTable.delegate = self
        
        view.backgroundColor = UIColor.lightGray
        view.isOpaque = false
    }
    
    override func viewWillAppear(_ animated: Bool) {
        getCollegeAPI()
}
    func getCollegeAPI() {
        APIHandler().getAPIValues(type: College.self
                                  , apiUrl: ServiceAPI.collegeURL, method: "GET") { result in
            switch result {
            case .success(let data):
                self.college = data
                print(self.college.data ?? "")
                print(self.college.data?.count ?? 0)
                DispatchQueue.main.async {
                    self.selectTable.reloadData()
                }
            case .failure(let error):
                print(error)
            }
        }
    }

/*extension SelectAreaVC: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return collegeListArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "ListAreaCell", for: indexPath) as! ListAreaCell
        
        cell.nameLbl.text = collegeListArray[indexPath.row]
        cell.radiobtn.addAction(for: .tap) {
            cell.radiobtn.setImage(UIImage(named: "radioon"), for: .normal)
           let nextVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "SelectSuperVisorVC") as! SelectSuperVisorVC
            self.navigationController?.pushViewController(nextVC, animated: true)
           
        }
        
        return cell
    }
//    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
//        <#code#>
//    }*/
    
    
}
extension SelectAreaVC : UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.college?.data?.count ?? 1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell =  tableView.dequeueReusableCell(withIdentifier: "ListAreaCell", for: indexPath) as! ListAreaCell
       
        if let college = self.college?.data?[indexPath.row] {
            
            cell.nameLbl.text = "\(college.buildingName ?? "")"
        } else {
            
            cell.nameLbl.text = "Nil"
        }
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 55
    }
}

