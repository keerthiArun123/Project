//
//  SelectSuperVisorVC.swift
//  Equipment Health
//
//  Created by Karthik Babu on 29/09/23.
//

import UIKit
import SideMenu

class SelectSuperVisorVC: UIViewController {
    
    @IBOutlet weak var tableView: UITableView!
    
    var supbuild: Supbuild!
    var menu: SideMenuNavigationController?

    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.delegate = self
        tableView.dataSource = self
        menu = SideMenuNavigationController(rootViewController: MenuListViewController())
        menu?.leftSide = false
        
        SideMenuManager.default.rightMenuNavigationController = menu
        SideMenuManager.default.addPanGestureToPresent(toView: self.view)
    }
    override func viewWillAppear(_ animated: Bool) {
        getSupbuildAPI()
}
    
    @IBAction func sideMenuAction(_ sender: Any) {
        present(menu!, animated: true, completion: nil)
    }
    
    @IBAction func ratings(_ sender: Any) {
        let nextVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "RatingVC") as! RatingVC
        self.navigationController?.pushViewController(nextVC, animated: true)
    }
    
    @IBAction func submit(_ sender: Any) {
        let nextVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "JobSuccessVC") as! JobSuccessVC
        self.navigationController?.pushViewController(nextVC, animated: true)
    }
    func getSupbuildAPI() {
        APIHandler().getAPIValues(type: Supbuild.self, apiUrl: ServiceAPI.supbuildURL, method: "GET") { result in
            switch result {
            case .success(let data):
                self.supbuild = data
                print(self.supbuild.data ?? "")
                print(self.supbuild.data?.count ?? 0)
                DispatchQueue.main.async {
                    self.tableView.reloadData()
                }
            case .failure(let error):
                print(error)
            }
        }
    }
    
}
extension SelectSuperVisorVC : UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.supbuild?.data?.count ?? 1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell =  tableView.dequeueReusableCell(withIdentifier: "ChooseClgTabCell", for: indexPath) as! ChooseClgTabCell
       
        if let supbuild = self.supbuild?.data?[indexPath.row] {
            
            cell.titleLbl.text = "\(supbuild.employeeName ?? "")"
            cell.clg.text = "\(supbuild.buildingName ?? "")"
        } else {
            
            cell.titleLbl.text = "Nil"
            cell.clg.text = "Nil"
        }
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 85
    }
}





