//
//  ChooseClgTabCell.swift
//  Equipment Health
//
//  Created by SAIL on 19/10/23.
//

import UIKit

class ChooseClgTabCell: UITableViewCell {

    
    
    @IBOutlet weak var view: UIView!
    @IBOutlet weak var titleLbl: UILabel!
    
    @IBOutlet weak var clg: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
