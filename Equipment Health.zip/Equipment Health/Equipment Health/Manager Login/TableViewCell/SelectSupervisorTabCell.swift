//
//  SelectSupervisorTabCell.swift
//  Equipment Health
//
//  Created by Karthik Babu on 29/09/23.
//

import UIKit

class SelectSupervisorTabCell: UITableViewCell {

    @IBOutlet weak var view: UIView!
    @IBOutlet weak var dropDown: UIButton!
    @IBOutlet weak var radioBtn: UIButton!
    @IBOutlet weak var name_Lbl: UILabel!
    @IBOutlet weak var clg_Lbl: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
