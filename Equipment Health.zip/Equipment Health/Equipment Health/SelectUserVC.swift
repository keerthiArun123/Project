//
//  SelectUserVC.swift
//  Equipment Health
//
//  Created by SAIL on 29/09/23.
//

import UIKit

class SelectUserVC: UIViewController {

    @IBOutlet weak var userView: UIView!
    @IBOutlet weak var techView: UIView!
    @IBOutlet weak var supervisorView: UIView!
    @IBOutlet weak var managerView: UIView!
    let navi = NavigationHelper()
    override func viewDidLoad() {
        super.viewDidLoad()
        userView.layer.cornerRadius = 10
        techView.layer.cornerRadius = 10
        supervisorView.layer.cornerRadius = 10
        managerView.layer.cornerRadius = 10
        navigationController?.isNavigationBarHidden = true
    
    }
    override func viewDidDisappear(_ animated: Bool) {
        navigationController?.isNavigationBarHidden = false

    }
    
    @IBAction func loginManager(_ sender: Any) {

        let nextVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "LoginViewController") as! LoginViewController
        self.navigationController?.pushViewController(nextVC, animated: true)
        
    }
    
    
    @IBAction func loginSupervisor(_ sender: Any) {
        let nextVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "LoginViewController") as! LoginViewController
        self.navigationController?.pushViewController(nextVC, animated: true)
    }
    
    @IBAction func loginTechnician(_ sender: Any) {
        let nextVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "LoginViewController") as! LoginViewController
        self.navigationController?.pushViewController(nextVC, animated: true)
    }
    
    @IBAction func loginUsr(_ sender: Any) {
            let nextVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "LoginViewController") as! LoginViewController
            self.navigationController?.pushViewController(nextVC, animated: true)
    }
    
}
