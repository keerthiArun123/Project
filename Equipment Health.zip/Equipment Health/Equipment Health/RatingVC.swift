//
//  RatingVC.swift
//  Equipment Health
//
//  Created by Karthik Babu on 29/09/23.
//

import UIKit

class RatingVC: UIViewController {

    @IBOutlet weak var tableView: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.delegate = self
        tableView.dataSource = self
        let nibCell = UINib(nibName: "RatingsTabCell", bundle: nil)
        tableView.register(nibCell, forCellReuseIdentifier: "RatingsTabCell")
        
        
    }
    @IBAction func submit(_ sender: Any) {
        let nextVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "JobSuccessVC") as! JobSuccessVC
         self.navigationController?.pushViewController(nextVC, animated: true)
    }
    
    
    

}


extension RatingVC :  UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 10
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "RatingsTabCell", for: indexPath) as! RatingsTabCell
        return cell
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        75
    }
}
