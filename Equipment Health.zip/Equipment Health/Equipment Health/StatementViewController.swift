//
//  StatementViewController.swift
//  Equipment Health
//
//  Created by SAIL on 21/11/23.
//

import UIKit

class StatementViewController: UIViewController {
    
    @IBOutlet weak var empName: UITextField!
    @IBOutlet weak var empId: UITextField!
    @IBOutlet weak var equipName: UITextField!
    @IBOutlet weak var equipId: UITextField!
    @IBOutlet weak var descriptions: UITextField!
    @IBOutlet weak var solvedDate: UITextField!
    
    var state: State!
    var details: TechDetailsModel!
    var EID: [TechnicianEquipment]!
    var EName: [TechnicianEmployee]!
    
    let datePicker : UIDatePicker = UIDatePicker()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        
        self.equipId.delegate = self
        self.equipName.delegate = self
        self.empId.delegate = self
        self.empName.delegate = self
        self.solvedDate.tag = 0
        self.solvedDate.delegate = self
    }
    
    override func viewWillAppear(_ animated: Bool) {
        GetDetailsAPI()
    }
    
    @IBAction func submitAction(_ sender: Any) {
        StatePostAPI()
    }
    
    func StatePostAPI() {
        
        let formData = [
            "employee_name" : self.empName.text ?? "",
            "employee_id" : self.empId.text ?? "",
            "description" : self.descriptions.text ?? "",
            "solved_date" : self.solvedDate.text ?? "",
            "equipment_id" : self.equipId.text ?? "",
            "equipment_name" : self.equipName.text ?? ""
        ]
        APIHandler().postAPIValues(type: State.self, apiUrl: ServiceAPI.StateURL, method: "POST", formData: formData) { result in
            switch result {
            case .success(let response):
                print(response.status ?? "")
                print(response.message ?? "")
                DispatchQueue.main.async {
                    AlertManager.showAlert(title: "\(response.status ?? "")", message: "\(response.message ?? "")", viewController: self) {
                        self.navigationController?.popViewController(animated: true)
                    }
                }
            case .failure(let error):
                print(error)
                print(error.localizedDescription)
            }
        }
    }
    
    func GetDetailsAPI() {
        APIHandler().getAPIValues(type: TechDetailsModel.self, apiUrl: ServiceAPI.techDetails, method: "GET") { result in
            switch result {
            case .success(let data):
                self.details = data
                self.EID = self.details.technicianEquipment
                self.EName = self.details.technicianEmployees
                DispatchQueue.main.async {
                    
                }
            case .failure(let error):
                print(error)
                print(error.localizedDescription)
            }
        }
    }
    
}

extension StatementViewController: UITextFieldDelegate {
    
    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool {
        
        if textField == empName {
            print("TextFieldShouldBeginEditing called for \(textField)")
            let equipmentIDs = self.EName.compactMap { $0.employeeName }
            AlertManager.showAction(title: "Select Employee", message: "", options: equipmentIDs, viewController: self) { selectedID in
                
                print(selectedID)
                
                textField.text = selectedID
            }
            return false
        } else if textField == empId{
            print("TextFieldShouldBeginEditing called for \(textField)")
            let equipmentIDs = self.EName.compactMap { $0.employeeID }
            AlertManager.showAction(title: "Select Employee ID", message: "", options: equipmentIDs, viewController: self) { selectedID in
                
                print(selectedID)
                
                textField.text = selectedID
            }
            return false
        } else if textField == equipName {
            print("TextFieldShouldBeginEditing called for \(textField)")
            let equipmentIDs = self.EID.compactMap { $0.equipmentName }
            AlertManager.showAction(title: "Select Equipment", message: "", options: equipmentIDs, viewController: self) { selectedID in
                
                print(selectedID)
                
                textField.text = selectedID
            }
            return false
        } else if textField == equipId {
            print("TextFieldShouldBeginEditing called for \(textField)")
            let equipmentIDs = self.EID.compactMap { $0.equipmentID }
            AlertManager.showAction(title: "Select Equipment ID", message: "", options: equipmentIDs, viewController: self) { selectedID in
                
                print(selectedID)
                
                textField.text = selectedID
            }
            return false
        } else if textField == solvedDate {
            textField.addTarget(self, action: #selector(dateTextFieldBeginEditing), for: .editingDidBegin)
        }
        return true
    }
    
    @objc func dateTextFieldBeginEditing(_ sender: UITextField) {
        showDatePicker(tag: sender.tag)
    }
    
    func showDatePicker(tag: Int){
        datePicker.datePickerMode = .date
        
        if #available(iOS 13.4, *) {
            datePicker.preferredDatePickerStyle = .wheels
        }
        else {
            datePicker.preferredDatePickerStyle = .wheels
        }
        let toolbar = UIToolbar();
        toolbar.sizeToFit()
        let doneButton = UIBarButtonItem(title: "Done", style: UIBarButtonItem.Style.done, target: self, action: #selector(self.donedatePicker(_ :)))
        doneButton.tag = tag
        let spaceButton = UIBarButtonItem(barButtonSystemItem: UIBarButtonItem.SystemItem.flexibleSpace, target: nil, action: nil)
        
        let cancelButton = UIBarButtonItem(title: "Cancel", style: UIBarButtonItem.Style.plain, target: self, action: #selector(self.cancelDatePicker(_ :)))
        cancelButton.tag = tag
        toolbar.setItems([cancelButton ,spaceButton,doneButton], animated: false)
        self.solvedDate.inputAccessoryView = toolbar
        self.solvedDate.inputView = datePicker
    }
    
    @objc func cancelDatePicker(_ sender: UIButton){
        self.solvedDate.text? = ""
        self.view.endEditing(true)
    }
    
    @objc func donedatePicker(_ sender: UIButton){
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy-MM-dd"
        self.solvedDate.text = formatter.string(from: datePicker.date)
        self.view.endEditing(true)
    }
}
