//
//  NotifyUserVC.swift
//  Equipment Health
//
//  Created by SAIL on 03/10/23.
//

import UIKit

class NotifyUserVC: UIViewController {

    @IBOutlet weak var nameTextField: UITextField!
    
    @IBOutlet weak var idTextField: UITextField!
    
    @IBOutlet weak var deliveryOn: UIButton!
    

    var datePicker = UIDatePicker()
    @IBOutlet weak var dateTextField: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        
        dateTextField.isHidden = true
        
    }
    
    

    
    @IBAction func deliveryDateAction(_ sender: Any) {
        
        self.dateTextField.isHidden = false
        
        self.datePicker.frame = CGRect(x: 40, y: 350, width: 300, height: 200)
        self.datePicker.preferredDatePickerStyle = .wheels
        self.datePicker.datePickerMode = .date
        
        let toolBar = UIToolbar()
        toolBar.barStyle = .default
        toolBar.isTranslucent = true
        toolBar.tintColor = .black
        toolBar.sizeToFit()
        
        let doneButton = UIBarButtonItem(title: "Done", style: UIBarButtonItem.Style.done, target: self, action: #selector(DoneAction))
        let spaceButton = UIBarButtonItem(barButtonSystemItem: UIBarButtonItem.SystemItem.fixedSpace, target: nil, action: nil)
        let cancelButton = UIBarButtonItem(title: "Cancel", style: UIBarButtonItem.Style.plain, target: self, action: #selector(CancelAction))
        
        toolBar.setItems([cancelButton, spaceButton, doneButton], animated: false)
        toolBar.isUserInteractionEnabled = true
        
        self.dateTextField.inputView = self.datePicker
        self.dateTextField.inputAccessoryView = toolBar
    }
    
    @objc func DoneAction() {
        let dateFormatter = DateFormatter()
            dateFormatter.dateStyle = .medium
            dateFormatter.timeStyle = .none
            let dateString = dateFormatter.string(from: datePicker.date)
            
            self.dateTextField.text = "Date : \(dateString)"
            self.dateTextField.resignFirstResponder()
    }
    
    @objc func CancelAction() {
        self.dateTextField.resignFirstResponder()
    }
    
    @IBAction func submit(_ sender: Any) {
        let nextVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "SupervisorHomeVC") as! SupervisorHomeVC
        self.navigationController?.pushViewController(nextVC, animated: true)
        
    }
    
    
    func NoteAPI() {
            let formData: [String: String] = [
                "equipment_name": nameTextField.text ?? "",
                "equipment_id": idTextField.text ?? "",
                
                
            ]
        APIHandler().postAPIValues(type: Note.self, apiUrl: ServiceAPI.NoteURL, method: "POST", formData: formData) { result in
                switch result {
                case .success(let response):
                    print("Status: \(response.status ?? "")")
                    print("Message: \(response.message ?? "")")
                    DispatchQueue.main.async {
                       print(formData)
                    }
                case .failure(let error):
                    print("Error: \(error)")
                }
            }
        }

    
}

