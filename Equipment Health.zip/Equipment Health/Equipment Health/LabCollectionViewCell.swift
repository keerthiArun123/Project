//
//  LabCollectionViewCell.swift
//  Equipment Health
//
//  Created by SAIL on 21/12/23.
//

import UIKit

class LabCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var labNameLabel: UILabel!
}
