//
//  AddFloorVC.swift
//  Equipment Health
//
//  Created by Karthik Babu on 29/09/23.
//

import UIKit

class AddLabVC: UIViewController {
    
    

    
    @IBOutlet weak var buildingName: UITextField!
    
    @IBOutlet weak var floorNo: UITextField!
    
    
    @IBOutlet weak var labName: UITextField!
    @IBOutlet weak var roomNo: UITextField!
    
    @IBOutlet weak var totalRooms: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func addAction(_ sender: Any) {
        self.AddlabAPI()
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    func AddlabAPI() {
            let formData: [String: String] = [
                "Building_name": buildingName.text ?? "",
                "floor": floorNo.text ?? "",
                "lab_name": labName.text ?? "",
                "room_no": roomNo.text ?? "",
                "total_rooms": totalRooms.text ?? "",
                /*"Designation": designationTextField.text ?? "",
                "contact_no": numberTextField.text ?? "",
                "Address": AddressTextField.text ?? "",
                "blood_group": bloodgroupTextField.text ?? ""*/
                
            ]
            APIHandler().postAPIValues(type: Addlab.self, apiUrl: ServiceAPI.AddlabURL, method: "POST", formData: formData) { result in
                switch result {
                case .success(let response):
                    print("Status: \(response.status ?? "")")
                    print("Message: \(response.message ?? "")")
                    DispatchQueue.main.async {
                       print(formData)
                    }
                case .failure(let error):
                    print("Error: \(error)")
                }
            }
        }

}
