<?php
// Include your database connection file
include 'dbconfig.php';

// Fetch the list of supervisors from the database
$query = "SELECT * FROM add_supervisor";
$result = $dbconn->query($query);

// Check if there are supervisors in the database
if ($result->num_rows > 0) {
    // Output data for each supervisor
    while ($row = $result->fetch_assoc()) {
        echo "Supervisor ID: " . $row['supervisor_id'] . "<br>";
        echo "Name: " . $row['supervisor_name'] . "<br>";
        // Add other fields as needed
        echo "--------------------------<br>";
    }
} else {
    // Output message if there are no supervisors
    echo "No supervisors found in the database.";
}

// Close the database connection
$dbconn->close();
?>