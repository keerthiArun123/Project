<?php
	session_start();
	if(ISSET($_POST['login'])){
		$username = $_POST['username'];
		$password = $_POST['password'];
		$conn = new mysqli("localhost", "root", "", "hcpms") or die(mysqli_error());
		$query = $conn->query("SELECT * FROM `user` WHERE `username` = '$username' && `password` = '$password'") or die(mysqli_error());
		$fetch = $query->fetch_array();
		$valid = $query->num_rows;
		$section = $fetch['section'];	
			if($valid > 0){
				if($section == "Bio lab"){
					$_SESSION['user_id'] = $fetch['user_id'];
					header("location: fecalysis.php");
				}
				if($section == "Chemistry lab"){
					$_SESSION['user_id'] = $fetch['user_id'];
					header("location: maternity.php");
				}
				if($section == "Physics lab"){
					$_SESSION['user_id'] = $fetch['user_id'];
					header("location: hematology.php");
				}
				if($section == "AR and VR lab"){
					$_SESSION['user_id'] = $fetch['user_id'];
					header("location: dental.php");
				}
				if($section == "Electronics lab"){
					$_SESSION['user_id'] = $fetch['user_id'];
					header("location: xray.php");
				}
				if($section == "Electrical lab"){
					$_SESSION['user_id'] = $fetch['user_id'];
					header("location: rehabilitation.php");
				}
				if($section == "Workshop and Mechanics lab"){
					$_SESSION['user_id'] = $fetch['user_id'];
					header("location: sputum.php");
				}
				if($section == "civil lab"){
					$_SESSION['user_id'] = $fetch['user_id'];
					header("location: urinalysis.php");
				}
			}else{
				echo "<script>alert('Account Does Not Exist!')</script>";
				echo "<script>window.location = 'index.php'</script>";
			}
						
		
		}
		$conn->close();
	